#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
# ============================================================
# Remote Server Management Script V2
# ============================================================
set -uo pipefail

# ── Resolve script directory
SCRIPT_PATH="${BASH_SOURCE[0]}"
while [[ -L "$SCRIPT_PATH" ]]; do
    SCRIPT_DIR="$(cd -P "$(dirname "$SCRIPT_PATH")" && pwd)"
    SCRIPT_PATH="$(readlink "$SCRIPT_PATH")"
    [[ "$SCRIPT_PATH" != /* ]] && SCRIPT_PATH="$SCRIPT_DIR/$SCRIPT_PATH"
done
SCRIPT_DIR="$(cd -P "$(dirname "$SCRIPT_PATH")" && pwd)"
LIB_DIR="$SCRIPT_DIR/lib"
CONFIG_DIR="$SCRIPT_DIR/config"
export SCRIPT_DIR LIB_DIR CONFIG_DIR

# ── Set default environment SEBELUM source apapun
export LOG_DIR="${LOG_DIR:-$HOME/.remoteserver}"
export BACKUP_DIR="${BACKUP_DIR:-$HOME/.remoteserver/backups}"
export TEMP_DIR="${TEMP_DIR:-/tmp/remoteserver-$$}"
export LOG_MAX_SIZE="${LOG_MAX_SIZE:-1048576}"
export BACKUP_RETENTION="${BACKUP_RETENTION:-30}"

export DEFAULT_SSH_PORT="${DEFAULT_SSH_PORT:-22}"
export SSH_DIR="${SSH_DIR:-$HOME/.ssh}"
export SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_rsa}"
export KNOWN_HOSTS="${KNOWN_HOSTS:-$SSH_DIR/known_hosts}"

export PARALLEL="${PARALLEL:-false}"
export MAX_PARALLEL="${MAX_PARALLEL:-5}"
export DRY_RUN="${DRY_RUN:-false}"
export DRY_RUN_SEND_SIMULATION="${DRY_RUN_SEND_SIMULATION:-true}"
export SSH_RETRY_MAX="${SSH_RETRY_MAX:-3}"
export SSH_RETRY_DELAY="${SSH_RETRY_DELAY:-3}"
export SSH_RETRY_DELAY_MULTIPLIER="${SSH_RETRY_DELAY_MULTIPLIER:-2}"
export HEALTH_TIMEOUT="${HEALTH_TIMEOUT:-300}"
export HEALTH_SERVER_TIMEOUT="${HEALTH_SERVER_TIMEOUT:-20}"
export VERBOSE="${VERBOSE:-false}"

export SERVER_LIST="${SERVER_LIST:-$SCRIPT_DIR/listserver.txt}"
export LOCK_FILE="${LOCK_FILE:-/tmp/remoteserver.lock}"

# ── Load core libraries
source "$LIB_DIR/core/colors.sh"
source "$LIB_DIR/core/logging.sh"
source "$LIB_DIR/core/config.sh"
source "$LIB_DIR/core/trap.sh"
source "$LIB_DIR/core/lock.sh"
source "$LIB_DIR/core/deps.sh"

validate_dependencies
load_config
validate_parallel_config
acquire_lock

source "$LIB_DIR/ssh/parse.sh"
source "$LIB_DIR/ssh/connect.sh"
source "$LIB_DIR/ssh/error_classify.sh"
source "$LIB_DIR/ssh/retry.sh"
source "$LIB_DIR/ssh/legacy.sh"
source "$LIB_DIR/ssh/test.sh"
source "$LIB_DIR/ssh/copyid.sh"
source "$LIB_DIR/ssh/sync.sh"

source "$LIB_DIR/core/exec.sh"
source "$LIB_DIR/core/rollback.sh"
source "$LIB_DIR/core/backup.sh"
source "$LIB_DIR/exec/envelope.sh"
source "$LIB_DIR/exec/worker.sh"
source "$LIB_DIR/server/list.sh"
source "$LIB_DIR/server/executor.sh"
source "$LIB_DIR/server/health.sh"

source "$LIB_DIR/validate/path.sh"
source "$LIB_DIR/validate/port.sh"
source "$LIB_DIR/validate/ip.sh"
source "$LIB_DIR/validate/user.sh"

# ── Load menus (urutan eksplisit)
source "$LIB_DIR/menus/00_main.sh"
source "$LIB_DIR/menus/01_ssh_key.sh"
source "$LIB_DIR/menus/02_ssh_list.sh"
source "$LIB_DIR/menus/03_maintainer.sh"
source "$LIB_DIR/menus/04_info.sh"
source "$LIB_DIR/menus/05_user.sh"
source "$LIB_DIR/menus/06_security.sh"
source "$LIB_DIR/menus/07_service.sh"
source "$LIB_DIR/menus/08_tools.sh"
source "$LIB_DIR/menus/09_tuneup.sh"
source "$LIB_DIR/menus/10_install.sh"

# ── Init
ensure_log_dir
mkdir -p "$SSH_DIR"
chmod 700 "$SSH_DIR"
cleanup_stale_temp

audit_log "INFO" "=== Script started (PID $$) ==="

if declare -f main_menu >/dev/null; then
    main_menu
else
    error "main_menu belum ada"
    exit 1
fi
