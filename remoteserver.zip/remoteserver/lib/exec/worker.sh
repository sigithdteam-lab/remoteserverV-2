#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
_worker_readonly() {
    local server="$1" task_name="$2" script="$3" out_file="$4"
    local start_ts; start_ts=$(date +%s%3N)
    {
        echo "════════════════════════════════════════"
        echo "Server: $server"
        echo "Task  : $task_name (read-only)"
        echo "════════════════════════════════════════"
        cel_remote_read "$server" "$task_name" "$script"
    } > "$out_file" 2>&1
    local rc=$?
    local duration=$(( $(date +%s%3N) - start_ts ))
    echo "$rc" > "${out_file}.rc"
    echo "$server|$rc|$duration" > "${out_file}.meta"
}

_worker_privileged() {
    local server="$1" task_name="$2" script="$3" out_file="$4"
    local start_ts; start_ts=$(date +%s%3N)
    {
        echo "════════════════════════════════════════"
        echo "Server: $server"
        echo "Task  : $task_name (privileged)"
        echo "════════════════════════════════════════"
        cel_remote_exec "$server" "$task_name" "$script"
    } > "$out_file" 2>&1
    local rc=$?
    local duration=$(( $(date +%s%3N) - start_ts ))
    echo "$rc" > "${out_file}.rc"
    echo "$server|$rc|$duration" > "${out_file}.meta"
}
