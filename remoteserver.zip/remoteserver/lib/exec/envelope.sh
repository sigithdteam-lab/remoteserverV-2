#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
build_env_prefix() {
    local prefix=""
    for kv in "$@"; do
        local k="${kv%%=*}"
        local v="${kv#*=}"
        [[ "$k" =~ ^[A-Z_][A-Z0-9_]*$ ]] || { error "Invalid env key: $k"; return 1; }
        prefix+="export ${k}=$(printf '%q' "$v"); "
    done
    printf '%s' "$prefix"
}

build_real_envelope() {
    local script="$1"; shift
    local env_prefix; env_prefix=$(build_env_prefix "$@") || return 1

    cat <<'HEADER'
#!/bin/bash
set -uo pipefail

if [[ "$(id -u)" -eq 0 ]]; then
    RS_EXEC_MODE="root_direct"
    SUDO=""
else
    if ! command -v sudo >/dev/null 2>&1; then
        echo "__RS_ERROR__: bukan root dan sudo tidak terinstall" >&2
        echo "__RS_HINT__: install sudo atau login sebagai root" >&2
        echo "__RS_EXEC_MODE__: no_sudo_binary" >&2
        exit 90
    fi
    if ! sudo -n true 2>/dev/null; then
        echo "__RS_ERROR__: user $(id -un) tidak punya NOPASSWD sudo" >&2
        echo "__RS_HINT__: sebagai root di $(hostname):" >&2
        echo "__RS_HINT__:   echo '$(id -un) ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/$(id -un)-rs" >&2
        echo "__RS_HINT__:   chmod 0440 /etc/sudoers.d/$(id -un)-rs" >&2
        echo "__RS_EXEC_MODE__: sudo_needs_password" >&2
        exit 90
    fi
    RS_EXEC_MODE="sudo_nopasswd"
    SUDO="sudo -n"
fi
export SUDO RS_EXEC_MODE
HEADER
    echo "$env_prefix"
    echo ""
    echo "exec bash -s <<'__RS_BODY__'"
    echo "$script"
    echo "__RS_BODY__"
}

build_readonly_envelope() {
    local script="$1"; shift
    local env_prefix; env_prefix=$(build_env_prefix "$@") || return 1

    cat <<'HEADER'
#!/bin/bash
set -uo pipefail
if [[ "$(id -u)" -eq 0 ]]; then SUDO=""; else SUDO="sudo -n"; fi
export SUDO
HEADER
    echo "$env_prefix"
    echo ""
    echo "exec bash -s <<'__RS_BODY__'"
    echo "$script"
    echo "__RS_BODY__"
}

build_dryrun_envelope() {
    local script="$1"; shift
    local env_prefix; env_prefix=$(build_env_prefix "$@") || return 1

    local dry_script
    dry_script=$(while IFS= read -r line; do
        local trimmed="${line#"${line%%[![:space:]]*}"}"
        if [[ "$trimmed" =~ ^(sudo|apt|apt-get|yum|dnf|zypper|systemctl|service|useradd|userdel|usermod|chpasswd|mysql|psql|certbot|ufw|firewall-cmd|iptables|nft|tee|mv|cp|rm|truncate|chown|chmod|mkdir|exportfs|hostnamectl|timedatectl)\  ]]; then
            printf 'dry %s\n' "$line"
        elif [[ "$trimmed" =~ ^sed\ .*-[a-z]*i ]]; then
            printf 'dry %s\n' "$line"
        else
            printf '%s\n' "$line"
        fi
    done <<< "$script")

    cat <<HEADER
#!/bin/bash
dry() { echo "[DRY-RUN] \$*"; }
$env_prefix
$dry_script
echo "__RS_RESULT__: OK (dry-run)"
exit 0
HEADER
}

build_real_envelope_with_dryrun() {
    local script="$1"; shift
    local env_prefix; env_prefix=$(build_env_prefix "$@") || return 1
    
    local is_dry="${DRY_RUN:-false}"

    cat <<HEADER
#!/bin/bash
set -uo pipefail
RS_DRY_RUN="$is_dry"
HEADER
    # Tambahkan deteksi sudo
    build_real_envelope_logic "$@"
    
    # Bungkus fungsi SUDO
    cat <<'BODY'
# Wrapper untuk eksekusi
if [ "$RS_DRY_RUN" = "true" ]; then
    SUDO_ORIG="$SUDO"
    SUDO="echo [DRY-RUN] $SUDO_ORIG"
fi
BODY
    echo "$env_prefix"
    echo ""
    echo "exec bash -s <<'__RS_BODY__'"
    echo "$script"
    echo "__RS_BODY__"
}
