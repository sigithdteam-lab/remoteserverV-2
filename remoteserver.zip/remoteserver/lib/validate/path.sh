#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
validate_scan_path() {
    local path="$1"
    [[ -z "${path// }" ]] && { error "Path kosong."; return 1; }
    [[ "$path" =~ [\;\|\&\$\`\(\)\{\}\<\>\"\'\\] ]] && {
        error "Path mengandung karakter berbahaya: '$path'"; return 1; }
    [[ "$path" == *".."* ]] && { error "Path traversal tidak diizinkan"; return 1; }
    [[ "$path" != /* ]] && { error "Path harus absolut: '$path'"; return 1; }
    (( ${#path} > 4096 )) && { error "Path terlalu panjang"; return 1; }
    case "$path" in
        /proc|/proc/*|/sys|/sys/*|/dev|/dev/*)
            error "Path sistem terlarang: '$path'"; return 1 ;;
    esac
    return 0
}
