#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
validate_username() {
    [[ "$1" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]
}
