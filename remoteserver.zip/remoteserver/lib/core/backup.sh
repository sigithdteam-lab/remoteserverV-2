#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
backup_with_retention() {
    local src="$1"
    local max="${2:-${BACKUP_RETENTION:-30}}"
    [[ ! -f "$src" ]] && return 0

    local dir; dir=$(dirname "$src")
    local base; base=$(basename "$src")
    local ts; ts=$(date +%Y%m%d%H%M%S)
    local bak="${dir}/${base}.remoteserver-backup.${ts}"

    cp -a "$src" "$bak" 2>/dev/null || return 1
    register_preserved_file "$bak"
    verbose_log "Backup: $bak"

    ls -1t "${dir}/${base}".remoteserver-backup.* 2>/dev/null | \
        tail -n +$((max + 1)) | while read -r old; do
            rm -f "$old" 2>/dev/null
        done
    return 0
}
