#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
apply_with_rollback() {
    local config_file=""
    local -a test_cmd=()
    local -a restart_cmd=()
    local mode="test"

    for arg in "$@"; do
        if [[ "$arg" == "--" ]]; then mode="restart"; continue; fi
        if [[ "$mode" == "test" ]]; then
            if [[ -z "$config_file" ]]; then config_file="$arg"
            else test_cmd+=("$arg"); fi
        else
            restart_cmd+=("$arg")
        fi
    done

    [[ -z "$config_file" ]] && { error "config_file kosong"; return 2; }
    [[ ! -f "$config_file" ]] && { error "config_file tidak ada: $config_file"; return 2; }
    [[ ${#test_cmd[@]} -eq 0 ]] && { error "test_cmd kosong"; return 2; }
    [[ ${#restart_cmd[@]} -eq 0 ]] && { error "restart_cmd kosong"; return 2; }

    case "$config_file" in
        /etc/passwd|/etc/shadow|/etc/group|/etc/gshadow|/etc/sudoers)
            error "config_file terlarang: $config_file"; return 2 ;;
    esac

    info "apply_with_rollback: $config_file"

    local backup
    backup="${config_file}.remoteserver-backup.$(date +%Y%m%d%H%M%S)"
    cp -a "$config_file" "$backup" 2>/dev/null || { error "Backup gagal"; return 1; }
    register_preserved_file "$backup"
    info "Backup: $backup"

    info "Test config ..."
    local test_out; test_out=$(exec_local "Test config" "${test_cmd[@]}" 2>&1) || {
        error "Config test GAGAL"
        echo "$test_out" >&2
        error "Rollback: restore dari $backup"
        cp -a "$backup" "$config_file" 2>/dev/null || error "Rollback GAGAL"
        audit_log "WARN" "apply_rollback: test_failed backup=$backup"
        return 1
    }
    info "Test OK"

    info "Restart service ..."
    local restart_out; restart_out=$(exec_local "Restart" "${restart_cmd[@]}" 2>&1) || {
        error "Restart GAGAL"
        echo "$restart_out" >&2
        error "Rollback: restore dari $backup"
        cp -a "$backup" "$config_file" 2>/dev/null || error "Rollback GAGAL"
        exec_local "Restart recovery" "${restart_cmd[@]}" >/dev/null 2>&1 || \
            warn "Recovery restart gagal"
        audit_log "WARN" "apply_rollback: restart_failed backup=$backup"
        return 1
    }
    info "Restart OK"
    info "apply_with_rollback: SUKSES ($config_file)"
    audit_log "INFO" "apply_success: $config_file backup=$backup"
    return 0
}
