#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
info()  { echo -e "${YELLOW}[INFO]${NC} $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
verbose_log() { [[ "${VERBOSE:-false}" == "true" ]] && echo -e "${CYAN}[DBG]${NC} $*" >&2 || true; }

ensure_log_dir() {
    local dir="${LOG_DIR:-$HOME/.remoteserver}"
    mkdir -p "$dir" 2>/dev/null
    chmod 700 "$dir" 2>/dev/null || true
}

_mask_secrets() {
    local s="$1"
    s=$(sed -E 's/(PASSWORD|SECRET|TOKEN|KEY|PASS|PWD)=[^ ]*/\1=***/gi' <<< "$s")
    printf '%s' "$s"
}

audit_log() {
    local event="$1"; shift
    local detail; detail=$(_mask_secrets "$*")
    ensure_log_dir
    local dir="${LOG_DIR:-$HOME/.remoteserver}"
    local log_file="${dir}/audit.jsonl"

    if [[ -f "$log_file" ]]; then
        local size; size=$(stat -c%s "$log_file" 2>/dev/null || echo 0)
        (( size > ${LOG_MAX_SIZE:-1048576} )) && mv "$log_file" "${log_file}.old" 2>/dev/null
    fi

    local ts; ts=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
    local user; user=$(id -un 2>/dev/null || echo unknown)
    local host; host=$(hostname -s 2>/dev/null || echo unknown)
    detail="${detail//\"/\\\"}"
    printf '{"ts":"%s","event":"%s","user":"%s","host":"%s","pid":%d,"detail":"%s"}\n' \
        "$ts" "$event" "$user" "$host" "$$" "$detail" >> "$log_file" 2>/dev/null || true
}

log_action() { audit_log "$@"; }

show_progress() {
    local current=$1 total=$2 label="${3:-}"
    [[ "$total" -eq 0 ]] && return
    local pct=$((current * 100 / total))
    if [[ -t 1 ]]; then
        printf "\r${CYAN}[%3d%%]${NC} (%d/%d) %-40s" "$pct" "$current" "$total" "$label"
        [[ "$current" -eq "$total" ]] && printf "\n"
    else
        printf "${CYAN}[%3d%%]${NC} (%d/%d) %s\n" "$pct" "$current" "$total" "$label"
    fi
}

confirm_action() {
    local msg="$1"
    echo -n "$msg (y/N): "
    read -r ans
    [[ "$ans" =~ ^[Yy]$ ]]
}

confirm_destructive() {
    local msg="$1" expect="$2"
    echo -e "${RED}${BOLD}[DESTRUKTIF]${NC} $msg"
    echo -en "Ketik '${BOLD}$expect${NC}' untuk konfirmasi: "
    read -r ans
    [[ "$ans" == "$expect" ]]
}
