#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
declare -a TEMP_FILES=() TEMP_DIRS=() PRESERVED_FILES=()

register_temp_file()     { [[ -n "$1" && "$1" != "/" ]] && TEMP_FILES+=("$1"); }
register_temp_dir()      { [[ -n "$1" && "$1" != "/" ]] && TEMP_DIRS+=("$1"); }
register_preserved_file(){ [[ -n "$1" ]] && PRESERVED_FILES+=("$1"); }

CURRENT_OPERATION=""
CURRENT_SERVER=""

cleanup_on_exit() {
    local exit_code=$?
    trap - EXIT INT TERM

    if [[ -n "$CURRENT_OPERATION" ]] && (( exit_code != 0 )); then
        echo ""
        echo -e "${RED}[INTERRUPTED]${NC} '$CURRENT_OPERATION' pada ${CURRENT_SERVER:-local} (exit=$exit_code)."
        audit_log "WARN" "INTERRUPTED op=$CURRENT_OPERATION server=${CURRENT_SERVER:-local} exit=$exit_code"
    fi

    for f in "${TEMP_FILES[@]}"; do [[ -f "$f" ]] && rm -f "$f" 2>/dev/null; done
    for d in "${TEMP_DIRS[@]}"; do [[ -d "$d" ]] && rm -rf "$d" 2>/dev/null; done

    audit_log "INFO" "Script exit (code=$exit_code)"
    exit $exit_code
}

cleanup_stale_temp() {
    for d in /tmp/remoteserver-*; do
        [[ ! -d "$d" ]] && continue
        local pid="${d#/tmp/remoteserver-}"
        [[ "$pid" =~ ^[0-9]+$ ]] && ! kill -0 "$pid" 2>/dev/null && rm -rf "$d" 2>/dev/null
    done
}

trap 'cleanup_on_exit' EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
