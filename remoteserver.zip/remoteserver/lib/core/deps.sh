#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
_check_and_install() {
    local pkg="$1"
    local cmd="${2:-$1}"

    command -v "$cmd" >/dev/null 2>&1 && return 0

    warn "Dependency hilang: $cmd (paket: $pkg)"

    local pm=""
    if command -v apt-get >/dev/null 2>&1; then pm="apt-get"
    elif command -v dnf >/dev/null 2>&1; then pm="dnf"
    elif command -v yum >/dev/null 2>&1; then pm="yum"
    elif command -v zypper >/dev/null 2>&1; then pm="zypper"
    else
        error "Package manager tidak dikenal. Install '$pkg' secara manual."
        return 1
    fi

    echo -n "Install $pkg sekarang? (y/N): "
    read -r ans
    if [[ "$ans" =~ ^[Yy]$ ]]; then
        info "Menginstal $pkg ..."
        local SUDO_EXEC=""
        [[ "$(id -u)" -ne 0 ]] && SUDO_EXEC="sudo"
        
        case "$pm" in
            apt-get) $SUDO_EXEC apt-get update -qq && $SUDO_EXEC apt-get install -y "$pkg" ;;
            dnf)     $SUDO_EXEC dnf install -y "$pkg" ;;
            yum)     $SUDO_EXEC yum install -y "$pkg" ;;
            zypper)  $SUDO_EXEC zypper install -y "$pkg" ;;
        esac

        if command -v "$cmd" >/dev/null 2>&1; then
            info "✓ $cmd berhasil diinstal."
            return 0
        else
            error "✗ Gagal menginstal $pkg."
            return 1
        fi
    else
        warn "Melewati instalasi $pkg."
        return 1
    fi
}

validate_dependencies() {
    echo ""
    info "Memeriksa dependencies di controller (lokal) ..."

    local critical=(bash ssh ssh-keygen ssh-copy-id grep sed awk cut sort head tail cat date mktemp)
    local missing=()
    for cmd in "${critical[@]}"; do
        command -v "$cmd" >/dev/null 2>&1 || missing+=("$cmd")
    done

    if [[ ${#missing[@]} -gt 0 ]]; then
        error "Dependency WAJIB hilang: ${missing[*]}"
        exit 1
    fi

    local optional=(
        "nmap:nmap" "traceroute:traceroute" "dnsutils:dig" 
        "whois:whois" "jq:jq" "curl:curl" 
        "openssl:openssl" "net-tools:netstat"
    )

    for item in "${optional[@]}"; do
        local pkg="${item%%:*}"
        local cmd="${item##*:}"
        if ! command -v "$cmd" >/dev/null 2>&1; then
            if [[ -t 0 ]]; then
                _check_and_install "$pkg" "$cmd" || true
            fi
        fi
    done
}
