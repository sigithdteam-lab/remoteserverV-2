#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
LOCK_FILE="${LOCK_FILE:-/tmp/remoteserver.lock}"
LOCK_METHOD=""

acquire_lock() {
    mkdir -p "$(dirname "$LOCK_FILE")"

    if command -v flock >/dev/null 2>&1; then
        exec 200>"$LOCK_FILE"
        if ! flock -n 200; then
            error "Script lain berjalan (lock: $LOCK_FILE)"
            error "  PID: $(cat "$LOCK_FILE" 2>/dev/null || echo unknown)"
            exit 1
        fi
        echo $$ >&200
        LOCK_METHOD="flock"
        info "Lock acquired: $LOCK_FILE (flock, FD=200)"
    else
        local lockdir="${LOCK_FILE}.d"
        if ! mkdir "$lockdir" 2>/dev/null; then
            error "Script lain berjalan (lock dir: $lockdir)"
            exit 1
        fi
        echo $$ > "$lockdir/pid"
        LOCK_METHOD="mkdir"
        register_temp_dir "$lockdir"
        info "Lock acquired: $lockdir (mkdir)"
    fi
}
