#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
load_config() {
    local config_file="${CONFIG_FILE:-$HOME/.remoteserver/config.conf}"

    # 1. Load file config DULU (Prioritas utama)
    if [[ -f "$config_file" ]]; then
        while IFS='=' read -r key value; do
            [[ "$key" =~ ^[[:space:]]*# ]] && continue
            [[ -z "${key// }" ]] && continue
            key="${key#"${key%%[![:space:]]*}"}"; key="${key%"${key##*[![:space:]]}"}"
            value="${value#"${value%%[![:space:]]*}"}"; value="${value%"${value##*[![:space:]]}"}"
            value="${value#\"}"; value="${value%\"}"
            value="${value#\'}"; value="${value%\'}"
            [[ "$key" =~ ^[A-Z_][A-Z0-9_]*$ ]] || continue
            # Tulis langsung (override default)
            export "$key=$value"
        done < "$config_file"
    fi

    # 2. Set default JIKA belum ada (fallback)
    export PARALLEL="${PARALLEL:-false}"
    export MAX_PARALLEL="${MAX_PARALLEL:-5}"
    export DRY_RUN="${DRY_RUN:-false}"
    export HEALTH_TIMEOUT="${HEALTH_TIMEOUT:-300}"
    
    if [[ -z "${DEFAULT_SSH_USER:-}" ]]; then
        _prompt_or_fail_default_user
    fi

    if [[ ! "${DEFAULT_SSH_USER}" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
        error "DEFAULT_SSH_USER tidak valid: '$DEFAULT_SSH_USER'"
        exit 1
    fi

    local port="${DEFAULT_SSH_PORT:-22}"
    if [[ ! "$port" =~ ^[0-9]+$ ]] || (( port < 1 || port > 65535 )); then
        error "DEFAULT_SSH_PORT tidak valid: '$port'"
        exit 1
    fi
    export DEFAULT_SSH_PORT="$port"
    export SSH_KEY="${SSH_KEY:-$HOME/.ssh/id_rsa}"
    export SSH_DIR="${SSH_DIR:-$HOME/.ssh}"
    export KNOWN_HOSTS="${KNOWN_HOSTS:-$SSH_DIR/known_hosts}"
}

_prompt_or_fail_default_user() {
    if [[ -t 0 ]]; then
        echo ""
        warn "DEFAULT_SSH_USER belum di-set."
        read -rp "Masukkan default SSH username: " input
        [[ -z "$input" ]] && { error "Tidak boleh kosong."; exit 1; }
        export DEFAULT_SSH_USER="$input"
        local config_file="${CONFIG_FILE:-$HOME/.remoteserver/config.conf}"
        mkdir -p "$(dirname "$config_file")"; chmod 700 "$(dirname "$config_file")"
        echo "DEFAULT_SSH_USER=\"$input\"" >> "$config_file"
        chmod 600 "$config_file"
    else
        error "DEFAULT_SSH_USER belum di-set. Export variabel atau buat config file."
        exit 1
    fi
}

validate_parallel_config() {
    [[ ! "${MAX_PARALLEL:-5}" =~ ^[0-9]+$ ]] && { error "MAX_PARALLEL harus angka"; exit 1; }
    (( MAX_PARALLEL < 1 || MAX_PARALLEL > 100 )) && { error "MAX_PARALLEL 1-100"; exit 1; }
}
