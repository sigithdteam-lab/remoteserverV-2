#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
exec_local() {
    local desc="$1"; shift
    if [[ "${DRY_RUN:-false}" == "true" ]]; then
        echo -e "${CYAN}[DRY-RUN LOCAL]${NC} $desc: $*"
        return 0
    fi
    audit_log "EXEC_LOCAL" "desc=$desc args=$*"
    "$@"
}

cel_remote_exec() {
    local server_str="$1" desc="$2" script="$3"; shift 3

    if ! parse_server_string "$server_str"; then
        error "Invalid server: $server_str"
        return 2
    fi

    local envelope
    if [[ "${DRY_RUN:-false}" == "true" ]]; then
        # Dry run envelope sekarang mengeksekusi script tapi mencegat perintah SUDO
        envelope=$(build_dryrun_envelope "$script" "$@")
    else
        envelope=$(build_real_envelope "$script" "$@")
    fi

    audit_log "REMOTE_EXEC" "server=$server_str desc=$desc dry_run=${DRY_RUN:-false}"

    local out_file; out_file=$(mktemp); register_temp_file "$out_file"
    local err_file; err_file=$(mktemp); register_temp_file "$err_file"
    local rc=0

    # GUNAKAN SSH EXEC DENGAN LEGACY FALLBACK!
    _ssh_exec_with_legacy "$server_str" "bash -s" \
        <<< "$envelope" > "$out_file" 2> "$err_file" || rc=$?

    cat "$out_file"
    [[ -s "$err_file" ]] && cat "$err_file" >&2

    if (( rc == 90 )); then
        error "[$server_str] Privilege insufficient (NOPASSWD sudo)."
    fi

    audit_log "REMOTE_RESULT" "server=$server_str desc=$desc rc=$rc"
    rm -f "$out_file" "$err_file"
    return $rc
}

cel_remote_read() {
    local server_str="$1" desc="$2" script="$3"; shift 3

    if ! parse_server_string "$server_str"; then
        error "Invalid server: $server_str"
        return 2
    fi

    local envelope; envelope=$(build_readonly_envelope "$script" "$@")
    audit_log "REMOTE_READ" "server=$server_str desc=$desc"

    local rc=0
    # GUNAKAN SSH EXEC DENGAN LEGACY FALLBACK!
    _ssh_exec_with_legacy "$server_str" "bash -s" <<< "$envelope" || rc=$?

    audit_log "REMOTE_READ_RESULT" "server=$server_str desc=$desc rc=$rc"
    return $rc
}
