#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
build_ssh_opts() {
    local port="$1"
    local opts=(
        -p "$port"
        -o StrictHostKeyChecking=accept-new
        -o UserKnownHostsFile="${KNOWN_HOSTS:-$SSH_DIR/known_hosts}"
        -o ConnectTimeout=15
        -o ServerAliveInterval=30
        -o ServerAliveCountMax=3
        -o LogLevel=ERROR
    )
    if [[ "$_S_IS_IPV6" != "true" ]] && _host_needs_legacy "$_S_HOST" "$_S_PORT" 2>/dev/null; then
        opts+=(
            -o PubkeyAcceptedAlgorithms=+ssh-rsa
            -o HostKeyAlgorithms=+ssh-rsa
        )
    fi
    printf '%s\n' "${opts[@]}"
}

_build_legacy_opts() {
    printf '%s\n' \
        -o PubkeyAcceptedAlgorithms=+ssh-rsa \
        -o HostKeyAlgorithms=+ssh-rsa \
        -o PubkeyAcceptedKeyTypes=+ssh-rsa
}

_is_legacy_error() {
    local err="$1"
    grep -qiE 'no matching (host key|key exchange)|signature algorithm|ssh-rsa|incorrect signature' <<< "$err"
}

_warn_host_key_changed() {
    local err_file="$1"
    local host_line; host_line=$(grep -oP 'Host key for \K\S+' "$err_file" 2>/dev/null | head -1)

    echo "" >&2
    echo -e "${RED}${BOLD}════════════════════════════════════════════════════════${NC}" >&2
    echo -e "${RED}${BOLD}  ⚠️  WARNING: HOST KEY BERUBAH${NC}" >&2
    echo -e "${RED}${BOLD}════════════════════════════════════════════════════════${NC}" >&2
    echo -e "${YELLOW}Host:${NC} ${host_line:-unknown}" >&2
    echo -e "Key di known_hosts BERBEDA dengan key server." >&2
    echo "" >&2
    echo -e "Kemungkinan: ${GREEN}server reinstall${NC} (legit) atau ${RED}MITM attack${NC}" >&2
    echo "" >&2
    echo -e "Perbaiki manual:" >&2
    echo -e "  ${CYAN}ssh-keygen -R \"${host_line:-<host>}\"${NC}" >&2
    echo -e "${RED}${BOLD}════════════════════════════════════════════════════════${NC}" >&2

    audit_log "SECURITY" "host_key_changed: ${host_line:-unknown}"
}
