#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
SSH_RETRY_MAX="${SSH_RETRY_MAX:-3}"
SSH_RETRY_DELAY="${SSH_RETRY_DELAY:-3}"
SSH_RETRY_DELAY_MULTIPLIER="${SSH_RETRY_DELAY_MULTIPLIER:-2}"
SSH_LAST_CATEGORY=""

_ssh_run() {
    local args=("$@")
    local attempt=0
    local delay="$SSH_RETRY_DELAY"

    while true; do
        local err_file; err_file=$(mktemp); register_temp_file "$err_file"

        ssh "${args[@]}" 2>"$err_file"
        local rc=$?

        if (( rc == 0 )); then
            rm -f "$err_file"
            return 0
        fi

        local category; category=$(_classify_ssh_error "$err_file")
        SSH_LAST_CATEGORY="$category"

        if (( rc != 255 )); then
            cat "$err_file" >&2
            rm -f "$err_file"
            return $rc
        fi

        if [[ -z "${SSH_RETRYABLE[$category]:-}" ]]; then
            _report_permanent_error "$category" "$err_file"
            rm -f "$err_file"
            return $rc
        fi

        if [[ "$category" == "CONNECTION_REFUSED" ]] && (( attempt >= 2 )); then
            warn "SSH [$category]: retry 2× gagal, menyerah"
            rm -f "$err_file"
            return $rc
        fi

        attempt=$((attempt + 1))
        if (( attempt > SSH_RETRY_MAX )); then
            warn "SSH [$category]: gagal setelah $SSH_RETRY_MAX attempt"
            cat "$err_file" >&2
            rm -f "$err_file"
            return $rc
        fi

        warn "SSH [$category]: retry $attempt/$SSH_RETRY_MAX dalam ${delay}s ..."
        rm -f "$err_file"
        sleep "$delay"

        delay=$((delay * SSH_RETRY_DELAY_MULTIPLIER))
        (( delay > 30 )) && delay=30
    done
}

_ssh_exec_with_legacy() {
    local server_str="$1"; shift
    parse_server_string "$server_str" || { error "Invalid: $server_str"; return 2; }

    local target; target=$(_ssh_target)
    local -a base_opts
    mapfile -t base_opts < <(build_ssh_opts "$_S_PORT")

    local rc=0
    _ssh_run "${base_opts[@]}" "$target" "$@" || rc=$?

    if (( rc == 0 )); then return 0; fi

    if [[ "$SSH_LAST_CATEGORY" == "HOST_KEY_CHANGED" ]]; then
        return 3
    fi

    if [[ "$SSH_LAST_CATEGORY" == "ALGO_MISMATCH" ]] || \
       [[ "$SSH_LAST_CATEGORY" == "LEGACY_RSA" ]]; then
        warn "Mencoba fallback legacy ssh-rsa untuk $target ..."
        local -a legacy_opts
        mapfile -t legacy_opts < <(_build_legacy_opts)

        rc=0
        _ssh_run "${base_opts[@]}" "${legacy_opts[@]}" "$target" "$@" || rc=$?

        if (( rc == 0 )); then
            info "Legacy ssh-rsa OK untuk $target"
            _mark_legacy_host "$_S_HOST" "$_S_PORT"
            return 0
        fi
    fi

    return $rc
}
