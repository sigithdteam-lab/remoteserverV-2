#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
ssh_copy_id_to_server() {
    local server_str="$1"
    parse_server_string "$server_str" || { error "Invalid: $server_str"; return 2; }

    local -a pub_keys=()
    for key in ed25519 ecdsa rsa; do
        local pub="$SSH_DIR/id_${key}.pub"
        [[ -f "$pub" ]] && pub_keys+=("$pub")
    done

    if [[ ${#pub_keys[@]} -eq 0 ]]; then
        error "Tidak ada public key. Generate dulu (Menu 1 → Opsi 1)."
        return 1
    fi

    local target; target=$(_ssh_target)
    local -a base_opts
    mapfile -t base_opts < <(build_ssh_opts "$_S_PORT")

    local stdin_src="/dev/stdin"
    if [[ -c /dev/tty ]] && [[ -r /dev/tty ]] && [[ -w /dev/tty ]]; then
        stdin_src="/dev/tty"
    fi

    info "Mengirim ${#pub_keys[@]} public key ke $server_str ..."

    local -a success_keys=()
    local -a failed_keys=()

    for pub in "${pub_keys[@]}"; do
        local key_type; key_type=$(basename "$pub" | sed 's/id_//;s/\.pub//')
        info "  Mengirim $key_type ..."
        if ssh-copy-id -i "$pub" "${base_opts[@]}" "$target" < "$stdin_src" 2>/dev/null; then
            info "    ✓ $key_type OK"
            success_keys+=("$key_type")
        else
            warn "    ✗ $key_type gagal"
            failed_keys+=("$key_type")
        fi
    done

    if [[ " ${failed_keys[*]} " == *" rsa "* ]]; then
        local rsa_pub="$SSH_DIR/id_rsa.pub"
        info "  Retry rsa via legacy ssh-rsa ..."
        local -a legacy_opts
        mapfile -t legacy_opts < <(_build_legacy_opts)

        if ssh-copy-id -i "$rsa_pub" "${base_opts[@]}" "${legacy_opts[@]}" \
                "$target" < "$stdin_src" 2>/dev/null; then
            info "    ✓ rsa legacy OK"
            success_keys+=("rsa")
            local -a new_failed=()
            for k in "${failed_keys[@]}"; do
                [[ "$k" != "rsa" ]] && new_failed+=("$k")
            done
            failed_keys=("${new_failed[@]}")
            _mark_legacy_host "$_S_HOST" "$_S_PORT"
        fi
    fi

    echo ""
    if [[ ${#success_keys[@]} -eq 0 ]]; then
        error "Semua key gagal dikirim ke $server_str"
        return 1
    fi

    info "Terkirim: ${success_keys[*]}"
    [[ ${#failed_keys[@]} -gt 0 ]] && warn "Gagal: ${failed_keys[*]}"

    info "Verifikasi passwordless ..."
    if test_passwordless_one "$server_str"; then
        info "✓ Passwordless OK"
        _save_successful_keys "$_S_HOST" "$_S_PORT" "${success_keys[*]}"
        return 0
    else
        error "Passwordless verifikasi GAGAL meski import sukses"
        return 1
    fi
}

_save_successful_keys() {
    local host="$1" port="$2" keys="$3"
    local marker_file="$LOG_DIR/ssh_key_success.txt"
    mkdir -p "$LOG_DIR"
    echo "$host:$port|$keys|$(date -u '+%Y-%m-%dT%H:%M:%SZ')" >> "$marker_file"
    chmod 600 "$marker_file"
}
