#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
_S_USER="" ; _S_HOST="" ; _S_PORT="" ; _S_IS_IPV6="false" ; _S_ERROR=""

_validate_username() { [[ "$1" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; }
_validate_port() {
    local p="$1"
    [[ "$p" =~ ^[0-9]{1,5}$ ]] || return 1
    (( p >= 1 && p <= 65535 )) || return 1
    return 0
}
_validate_ipv4() {
    local ip="$1"
    [[ "$ip" =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || return 1
    local IFS='.'
    for octet in $ip; do (( octet >= 0 && octet <= 255 )) || return 1; done
    return 0
}
_validate_ipv6() {
    local ip="$1"
    [[ "$ip" == *:* ]] || return 1
    [[ "$ip" =~ ^[0-9a-fA-F:]+$ ]] || return 1
    [[ "$ip" == *":::"* ]] && return 1
    (( ${#ip} <= 45 )) || return 1
    return 0
}
_validate_hostname() {
    [[ -z "$1" ]] && return 1
    [[ "$1" =~ ^[a-zA-Z0-9]([a-zA-Z0-9._-]{0,252}[a-zA-Z0-9])?$ ]]
}

parse_server_string() {
    local input="$1"
    _S_USER="" ; _S_HOST="" ; _S_PORT="" ; _S_IS_IPV6="false" ; _S_ERROR=""

    input="${input#"${input%%[![:space:]]*}"}"
    input="${input%"${input##*[![:space:]]}"}"

    [[ -z "$input" ]] && { _S_ERROR="input kosong"; return 1; }
    [[ "$input" =~ [[:space:]\;\|\&\$\`\(\)\{\}\<\>\"\'\\] ]] && {
        _S_ERROR="mengandung karakter berbahaya"; return 1
    }

    local rest="$input"
    if [[ "$rest" == *"@"* ]]; then
        local at_count="${rest//[^@]/}"
        (( ${#at_count} > 1 )) && { _S_ERROR="multiple @"; return 1; }
        _S_USER="${rest%%@*}"; rest="${rest#*@}"
        [[ -z "$_S_USER" ]] && { _S_ERROR="username kosong"; return 1; }
        _validate_username "$_S_USER" || { _S_ERROR="username tidak valid: '$_S_USER'"; return 1; }
    fi
    [[ -z "$rest" ]] && { _S_ERROR="host kosong"; return 1; }

    if [[ "$rest" == \[* ]]; then
        [[ "$rest" != *"]"* ]] && { _S_ERROR="bracket tidak lengkap"; return 1; }
        local inside="${rest#\[}"; inside="${inside%%\]*}"
        local after="${rest#*\]}"
        _validate_ipv6 "$inside" || { _S_ERROR="IPv6 tidak valid"; return 1; }
        _S_HOST="$inside"; _S_IS_IPV6="true"
        if [[ -n "$after" ]]; then
            [[ "$after" != :* ]] && { _S_ERROR="karakter setelah ']' invalid"; return 1; }
            local p="${after#:}"
            _validate_port "$p" || { _S_ERROR="port tidak valid: '$p'"; return 1; }
            _S_PORT="$p"
        else
            _S_PORT="${DEFAULT_SSH_PORT:-22}"
        fi
    elif [[ "$rest" =~ ^[0-9a-fA-F:]+$ ]] && [[ "$(tr -cd ':' <<< "$rest" | wc -c)" -ge 2 ]]; then
        _validate_ipv6 "$rest" || { _S_ERROR="IPv6 ambigu, pakai [ipv6]:port"; return 1; }
        _S_HOST="$rest"; _S_IS_IPV6="true"; _S_PORT="${DEFAULT_SSH_PORT:-22}"
    else
        if [[ "$rest" == *":"* ]]; then
            local cc="${rest//[^:]/}"
            (( ${#cc} > 1 )) && { _S_ERROR="multiple ':'"; return 1; }
            _S_HOST="${rest%:*}"; _S_PORT="${rest#*:}"
            _validate_port "$_S_PORT" || { _S_ERROR="port invalid"; return 1; }
        else
            _S_HOST="$rest"; _S_PORT="${DEFAULT_SSH_PORT:-22}"
        fi
        if ! _validate_ipv4 "$_S_HOST" && ! _validate_hostname "$_S_HOST"; then
            _S_ERROR="host tidak valid: '$_S_HOST'"; return 1
        fi
    fi

    if [[ -z "$_S_USER" ]]; then
        [[ -z "${DEFAULT_SSH_USER:-}" ]] && { _S_ERROR="DEFAULT_SSH_USER kosong"; return 1; }
        _S_USER="$DEFAULT_SSH_USER"
    fi
    return 0
}

_ssh_target() {
    if [[ "$_S_IS_IPV6" == "true" ]]; then
        echo "${_S_USER}@[${_S_HOST}]"
    else
        echo "${_S_USER}@${_S_HOST}"
    fi
}

_known_hosts_key() {
    if [[ "$_S_PORT" == "22" ]]; then
        [[ "$_S_IS_IPV6" == "true" ]] && echo "[$_S_HOST]" || echo "$_S_HOST"
    else
        echo "[$_S_HOST]:$_S_PORT"
    fi
}

_format_display() {
    local t; t=$(_ssh_target)
    [[ "$_S_PORT" != "22" ]] && echo "${t}:$_S_PORT" || echo "$t"
}
