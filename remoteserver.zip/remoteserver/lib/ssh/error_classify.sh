#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
declare -A SSH_ERROR_CATEGORIES=(
    [TIMEOUT]="Connection timed out|Operation timed out|Timeout"
    [CONNECTION_RESET]="Connection reset by peer|Broken pipe|Connection closed by"
    [CONNECTION_REFUSED]="Connection refused"
    [NO_ROUTE]="No route to host|Network is unreachable"
    [AUTH_FAILED]="Permission denied|Authentication failed|publickey"
    [TOO_MANY_AUTH]="Too many authentication failures"
    [HOST_KEY_CHANGED]="REMOTE HOST IDENTIFICATION HAS CHANGED|Host key verification failed"
    [ALGO_MISMATCH]="no matching key exchange|no matching host key|no matching cipher|signature algorithm"
    [LEGACY_RSA]="ssh-rsa|PubkeyAcceptedAlgorithms"
    [DNS_FAILED]="Could not resolve hostname|Name or service not known|Temporary failure in name resolution"
)

declare -A SSH_RETRYABLE=(
    [TIMEOUT]=1
    [CONNECTION_RESET]=1
    [CONNECTION_REFUSED]=1
)

_classify_ssh_error() {
    local err_file="$1"
    local err; err=$(cat "$err_file" 2>/dev/null)

    for category in "${!SSH_ERROR_CATEGORIES[@]}"; do
        if grep -qiE "${SSH_ERROR_CATEGORIES[$category]}" <<< "$err"; then
            echo "$category"; return 0
        fi
    done
    echo "UNKNOWN"
}

_report_permanent_error() {
    local category="$1"
    local err_file="$2"

    case "$category" in
        AUTH_FAILED)
            error "SSH AUTH gagal: kredensial ditolak (publickey)."
            error "  Perbaiki: import key (Menu 1 → Opsi 2)"
            ;;
        TOO_MANY_AUTH)
            error "SSH: terlalu banyak auth attempts."
            error "  Perbaiki: cek ~/.ssh/config (IdentitiesOnly yes)"
            ;;
        HOST_KEY_CHANGED)
            _warn_host_key_changed "$err_file"
            ;;
        NO_ROUTE)
            error "SSH: host unreachable."
            ;;
        DNS_FAILED)
            error "SSH: DNS gagal resolve."
            ;;
        ALGO_MISMATCH|LEGACY_RSA)
            warn "SSH: algoritma tidak cocok (akan coba legacy)."
            ;;
        *)
            error "SSH gagal: kategori $category"
            ;;
    esac

    echo "" >&2
    tail -5 "$err_file" >&2 2>/dev/null || true
    echo "" >&2

    audit_log "ERROR" "ssh_fail: category=$category"
}
