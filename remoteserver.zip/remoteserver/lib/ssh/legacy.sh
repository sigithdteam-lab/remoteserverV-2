#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
LEGACY_MARKER_FILE="${LOG_DIR:-$HOME/.remoteserver}/legacy_hosts.txt"

_mark_legacy_host() {
    local host="$1" port="$2"
    ensure_log_dir
    local key="$host:$port"
    [[ -f "$LEGACY_MARKER_FILE" ]] && grep -qxF "$key" "$LEGACY_MARKER_FILE" && return 0
    echo "$key" >> "$LEGACY_MARKER_FILE"
    chmod 600 "$LEGACY_MARKER_FILE"
    verbose_log "Legacy host ditandai: $key"
}

_host_needs_legacy() {
    local host="$1" port="$2"
    local key="$host:$port"
    [[ -f "$LEGACY_MARKER_FILE" ]] && grep -qxF "$key" "$LEGACY_MARKER_FILE"
}
