#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
test_passwordless_one() {
    local server_str="$1"
    parse_server_string "$server_str" || { echo "INVALID" >&2; return 2; }

    local target; target=$(_ssh_target)
    local -a base_opts
    mapfile -t base_opts < <(build_ssh_opts "$_S_PORT")
    base_opts+=(
        -o BatchMode=yes
        -o PreferredAuthentications=publickey
        -o PasswordAuthentication=no
    )

    local err_file; err_file=$(mktemp); register_temp_file "$err_file"
    local rc=0
    ssh "${base_opts[@]}" "$target" 'echo __OK__' >/dev/null 2>"$err_file" || rc=$?

    if (( rc == 0 )); then
        rm -f "$err_file"
        return 0
    fi

    local err; err=$(cat "$err_file" 2>/dev/null); rm -f "$err_file"

    if grep -qiE 'REMOTE HOST IDENTIFICATION HAS CHANGED|Host key verification failed' <<< "$err"; then
        echo "HOST_KEY_CHANGED" >&2
        return 3
    fi
    if grep -qiE 'no matching|signature algorithm|ssh-rsa' <<< "$err"; then
        echo "LEGACY_NEEDED" >&2
        return 1
    fi
    if grep -qiE 'Permission denied|publickey' <<< "$err"; then
        echo "AUTH_FAILED" >&2
        return 1
    fi
    if grep -qiE 'Connection timed out|No route|Connection refused' <<< "$err"; then
        echo "NETWORK_ERROR" >&2
        return 1
    fi
    echo "UNKNOWN" >&2
    return 1
}
