#!/bin/bash
_health_check_one() {
    local server="$1"
    parse_server_string "$server" || return 1

    local ssh_status="FAIL" auth_status="-" ping_ms="-" uptime_str="-" \
          disk_pct="-" load_str="-" ram_pct="-" services="-"

    if command -v ping >/dev/null 2>&1; then
        local p
        p=$(ping -c 1 -W 2 "$_S_HOST" 2>/dev/null | grep -oP 'time=\K[0-9.]+' | head -1)
        [[ -n "$p" ]] && ping_ms="${p}ms"
    fi

    local script
    script=$(cat <<'REMOTE'
echo "HOSTNAME:$(hostname 2>/dev/null)"
echo "UPTIME:$(uptime -p 2>/dev/null | sed 's/^up //')"
echo "DISK:$(df -h / 2>/dev/null | awk 'NR==2 {gsub(/%/,"",$5); print $5}')"
echo "LOAD:$(awk '{print $1}' /proc/loadavg 2>/dev/null)"
echo "RAM:$(free -m 2>/dev/null | awk '/Mem:/ {print int($3*100/$2)}')"
REMOTE
)
    local remote_data; remote_data=$(cel_remote_read "$server" "health" "$script" 2>/dev/null)
    local rc=$?

    if (( rc == 0 )); then
        ssh_status="OK"
        uptime_str=$(awk -F: '/^UPTIME:/{sub(/^UPTIME:/,""); print}' <<< "$remote_data")
        disk_pct=$(awk -F: '/^DISK:/{sub(/^DISK:/,""); print}' <<< "$remote_data")
        load_str=$(awk -F: '/^LOAD:/{sub(/^LOAD:/,""); print}' <<< "$remote_data")
        ram_pct=$(awk -F: '/^RAM:/{sub(/^RAM:/,""); print}' <<< "$remote_data")

        if test_passwordless_one "$server" >/dev/null 2>&1; then auth_status="OK"; else auth_status="FAIL"; fi
    fi

    [[ -z "$uptime_str" ]] && uptime_str="-"
    [[ -z "$disk_pct" ]] && disk_pct="-"
    [[ -z "$load_str" ]] && load_str="-"
    [[ -z "$ram_pct" ]] && ram_pct="-"

    echo "$server|$ssh_status|$auth_status|$ping_ms|$uptime_str|$disk_pct|$load_str|$ram_pct|$services"
    return 0
}

health_check_dashboard() {
    read_servers; select_servers || return
    local total=${#SELECTED_INDICES[@]}
    local mode_desc
    [[ "${PARALLEL:-false}" == "true" ]] && mode_desc="parallel (max=$MAX_PARALLEL)" || mode_desc="sequential"

    info "Health check $total server — mode: $mode_desc"
    echo ""

    local results=()
    local n=0 idx
    for idx in "${SELECTED_INDICES[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"
        local r; r=$(_health_check_one "$server")
        results+=("$r")
    done
    echo ""
    echo ""

    printf "%-25s | %-4s | %-4s | %-7s | %-12s | %-5s | %-8s | %-5s\n" \
        "Server" "SSH" "Auth" "Ping" "Uptime" "Disk" "Load" "RAM"
    printf '%.0s-' {1..100}; echo

    local r
    for r in "${results[@]}"; do
        [[ -z "$r" ]] && continue
        local sv ssh_st auth_st ping_s up_s disk_p load_s ram_p svcs
        IFS='|' read -r sv ssh_st auth_st ping_s up_s disk_p load_s ram_p svcs <<< "$r"
        printf "%-25s | %-4s | %-4s | %-7s | %-12s | %-5s | %-8s | %s%%\n" \
            "$sv" "$ssh_st" "$auth_st" "$ping_s" "$up_s" "$disk_p" "$load_s" "$ram_p"
    done
    printf '%.0s-' {1..100}; echo
}
