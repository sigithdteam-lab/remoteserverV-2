#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

_run_sequential_generic() {
    local worker_func="$1" script="$2" task_name="$3"
    shift 3
    local indices=("$@")

    local total=${#indices[@]} n=0
    local ok=0 fail=0
    local summary_lines=()
    local results_dir; results_dir=$(mktemp -d); register_temp_dir "$results_dir"

    for idx in "${indices[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"

        local out_file="$results_dir/out_${n}.log"
        # Jalankan dalam subshell agar exit code tidak mematikan loop
        (
            "$worker_func" "$server" "$task_name" "$script" "$out_file"
        ) || true
        
        echo ""
        cat "$out_file" 2>/dev/null
        echo ""

        local rc=0
        [[ -f "${out_file}.rc" ]] && rc=$(cat "${out_file}.rc")
        
        local duration="-"
        [[ -f "${out_file}.meta" ]] && duration=$(cut -d'|' -f3 "${out_file}.meta")

        if (( rc == 0 )); then
            ok=$((ok+1)); summary_lines+=("OK|$server|$duration|rc=0")
        else
            fail=$((fail+1)); summary_lines+=("FAIL|$server|$duration|rc=$rc")
        fi
    done

    _print_summary "$task_name" "$total" "$ok" "$fail" 0 "sequential" "${summary_lines[@]}"
}

_run_parallel_generic() {
    local worker_func="$1" script="$2" task_name="$3"
    shift 3
    local indices=("$@")

    local total=${#indices[@]} n=0
    local ok=0 fail=0 timeout=0
    local summary_lines=()
    local results_dir; results_dir=$(mktemp -d); register_temp_dir "$results_dir"

    local pids=()
    declare -A pid_to_server pid_to_outfile pid_to_start

    for idx in "${indices[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"

        while [[ ${#pids[@]} -ge ${MAX_PARALLEL:-5} ]]; do
            wait -n 2>/dev/null || true
            local new_pids=()
            for p in "${pids[@]}"; do kill -0 "$p" 2>/dev/null && new_pids+=("$p"); done
            pids=("${new_pids[@]}")
        done

        local out_file="$results_dir/out_${n}.log"
        "$worker_func" "$server" "$task_name" "$script" "$out_file" &
        local pid=$!
        pids+=("$pid")
        pid_to_server[$pid]="$server"
        pid_to_outfile[$pid]="$out_file"
        pid_to_start[$pid]=$(date +%s)
    done

    for pid in "${pids[@]}"; do
        local server="${pid_to_server[$pid]}"
        local out_file="${pid_to_outfile[$pid]}"
        local start_time="${pid_to_start[$pid]}"
        local server_timeout="${HEALTH_SERVER_TIMEOUT:-20}" # Default 20 detik per server
        
        local killed=false
        while kill -0 "$pid" 2>/dev/null; do
            sleep 0.2
            local now=$(date +%s)
            if (( now - start_time > server_timeout )); then
                warn "Timeout: $server (lebih dari ${server_timeout}s)"
                kill -TERM "$pid" 2>/dev/null; sleep 1; kill -KILL "$pid" 2>/dev/null
                killed=true; break
            fi
        done

        local rc=0 status duration="-"
        if [[ "$killed" == "true" ]]; then
            rc=124; status="TIMEOUT"; timeout=$((timeout+1))
        elif [[ -f "${out_file}.rc" ]]; then
            rc=$(cat "${out_file}.rc")
            [[ -f "${out_file}.meta" ]] && duration=$(cut -d'|' -f3 "${out_file}.meta")
            if (( rc == 0 )); then ok=$((ok+1)); status="OK"
            else fail=$((fail+1)); status="FAIL"; fi
        else
            rc=1; status="FAIL"; fail=$((fail+1))
        fi
        summary_lines+=("$status|$server|$duration|rc=$rc")
    done

    echo ""
    for pid in "${pids[@]}"; do
        cat "${pid_to_outfile[$pid]}" 2>/dev/null; echo ""
    done

    _print_summary "$task_name" "$total" "$ok" "$fail" "$timeout" "parallel" "${summary_lines[@]}"
}

_print_summary() {
    local task_name="$1" total="$2" ok="$3" fail="$4" timeout="$5" mode="$6"
    shift 6
    local lines=("$@")

    echo "═══════════════════════════════════════════════════════"
    echo "  SUMMARY: $task_name (mode=$mode)"
    echo "═══════════════════════════════════════════════════════"
    printf "  %-12s : %d\n" "Total" "$total"
    printf "  %-12s : ${GREEN}%d${NC}\n" "SUCCESS" "$ok"
    printf "  %-12s : ${RED}%d${NC}\n"   "FAILED"  "$fail"
    [[ "$mode" == "parallel" ]] && printf "  %-12s : ${YELLOW}%d${NC}\n" "TIMEOUT" "$timeout"
    
    printf "  %-4s %-25s %-8s %-10s %s\n" "#" "Server" "Status" "Duration" "Reason"
    printf '%.0s-' {1..80}; echo
    local i=0
    for line in "${lines[@]}"; do
        i=$((i+1))
        IFS='|' read -r status server duration reason <<< "$line"
        local color="${RED}"
        [[ "$status" == "OK" ]] && color="${GREEN}"
        [[ "$status" == "TIMEOUT" ]] && color="${YELLOW}"
        printf "  %-4d %-25s ${color}%-8s${NC} %-10s %s\n" "$i" "$server" "$status" "${duration}ms" "$reason"
    done
    printf '%.0s-' {1..80}; echo
}

run_action_on_servers_readonly() {
    local script="$1" task_name="$2"
    read_servers; select_servers || return
    local indices=("${SELECTED_INDICES[@]}")

    if [[ "${PARALLEL:-false}" == "true" ]]; then
        info "Mode: parallel (max=$MAX_PARALLEL)"
        _run_parallel_generic _worker_readonly "$script" "$task_name" "${indices[@]}"
    else
        info "Mode: sequential"
        _run_sequential_generic _worker_readonly "$script" "$task_name" "${indices[@]}"
    fi
}

run_action_on_servers_privileged() {
    local script="$1" task_name="$2"
    read_servers; select_servers || return
    local indices=("${SELECTED_INDICES[@]}")

    if [[ "${PARALLEL:-false}" == "true" ]]; then
        info "Mode: parallel (max=$MAX_PARALLEL)"
        _run_parallel_generic _worker_privileged "$script" "$task_name" "${indices[@]}"
    else
        info "Mode: sequential"
        _run_sequential_generic _worker_privileged "$script" "$task_name" "${indices[@]}"
    fi
}
