#!/bin/bash
SERVER_LIST="${SERVER_LIST:-listserver.txt}"
SERVERS_CACHED=()
SERVERS_LOADED=false
SELECTED_INDICES=()

read_servers() {
    [[ "$SERVERS_LOADED" == "true" ]] && return 0
    if [[ ! -f "$SERVER_LIST" ]]; then
        touch "$SERVER_LIST"
        info "Created: $SERVER_LIST"
    fi
    mapfile -t SERVERS_CACHED < <(grep -v '^[[:space:]]*$' "$SERVER_LIST" | grep -v '^[[:space:]]*#' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    SERVERS_LOADED=true
}

refresh_servers() { SERVERS_LOADED=false; read_servers; }

display_servers() {
    [[ ${#SERVERS_CACHED[@]} -eq 0 ]] && { warn "No servers."; return 1; }
    echo "Available servers:"
    local i
    for i in "${!SERVERS_CACHED[@]}"; do
        echo "  $((i+1))) ${SERVERS_CACHED[$i]}"
    done
}

select_servers() {
    SELECTED_INDICES=()
    [[ ${#SERVERS_CACHED[@]} -eq 0 ]] && { warn "No servers."; return 1; }
    display_servers
    echo "Enter: 1,2 atau 1-3 atau all"
    read -r selection
    selection=$(echo "$selection" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -z "$selection" ]] && { warn "No input."; return 1; }

    if [[ "$selection" == "all" ]]; then
        local i
        for i in "${!SERVERS_CACHED[@]}"; do SELECTED_INDICES+=("$((i+1))"); done
    else
        IFS=',' read -ra parts <<< "$selection"
        local part
        for part in "${parts[@]}"; do
            part=$(echo "$part" | tr -d '[:space:]')
            if [[ "$part" =~ ^[0-9]+$ ]]; then
                SELECTED_INDICES+=("$part")
            elif [[ "$part" =~ ^([0-9]+)-([0-9]+)$ ]]; then
                local st="${BASH_REMATCH[1]}" en="${BASH_REMATCH[2]}"
                (( st <= en )) && for ((i=st; i<=en; i++)); do SELECTED_INDICES+=("$i"); done
            fi
        done
    fi

    [[ ${#SELECTED_INDICES[@]} -eq 0 ]] && { warn "No selection."; return 1; }

    local sorted=()
    while IFS= read -r num; do sorted+=("$num"); done < <(printf '%s\n' "${SELECTED_INDICES[@]}" | sort -nu)
    SELECTED_INDICES=("${sorted[@]}")

    local max=${#SERVERS_CACHED[@]}
    local valid=()
    local idx
    for idx in "${SELECTED_INDICES[@]}"; do
        (( idx >= 1 && idx <= max )) && valid+=("$idx") || warn "Index $idx out of range"
    done
    SELECTED_INDICES=("${valid[@]}")
    [[ ${#SELECTED_INDICES[@]} -eq 0 ]] && return 1
    return 0
}

get_server_by_index() {
    local idx=$1
    (( idx >= 1 && idx <= ${#SERVERS_CACHED[@]} )) && echo "${SERVERS_CACHED[$((idx-1))]}"
}
