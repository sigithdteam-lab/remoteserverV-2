#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

generate_ssh_key() {
    info "Generate SSH keys (semua tipe) ..."
    echo ""
    echo "Tipe: ed25519, ecdsa (521), rsa (4096)"
    echo ""

    if ! confirm_action "Generate ketiga tipe key sekarang?"; then
        info "Dibatalkan."; return 1
    fi

    mkdir -p "$SSH_DIR"; chmod 700 "$SSH_DIR"
    local timestamp; timestamp=$(date '+%Y%m%d%H%M%S')
    local -a generated=() skipped=() failed=()

    _gen_one_key() {
        local key_type="$1" key_bits="$2" key_file="$3"
        if [[ -f "$key_file" ]]; then
            warn "  • $key_type sudah ada, skip"; skipped+=("$key_type"); return 0
        fi
        info "  • Generating $key_type ..."
        local gen_args=(-t "$key_type" -f "$key_file" -N "" -C "rs-${key_type}-${timestamp}")
        [[ -n "$key_bits" ]] && gen_args+=(-b "$key_bits")
        if ssh-keygen "${gen_args[@]}" 2>&1 | grep -v '^Generating'; then
            chmod 600 "$key_file"; chmod 644 "${key_file}.pub"
            generated+=("$key_type"); info "    ✓ $key_type OK"
        else
            failed+=("$key_type"); error "    ✗ $key_type gagal"
        fi
    }

    _gen_one_key "ed25519" "" "$SSH_DIR/id_ed25519"
    _gen_one_key "ecdsa" "521" "$SSH_DIR/id_ecdsa"
    _gen_one_key "rsa" "4096" "$SSH_DIR/id_rsa"

    echo ""
    echo "═══════════════════════════════════════════════════════════"
    echo "  SUMMARY"
    echo "═══════════════════════════════════════════════════════════"
    [[ ${#generated[@]} -gt 0 ]] && echo -e "  ${GREEN}✓ Generated${NC}: ${generated[*]}"
    [[ ${#skipped[@]} -gt 0 ]] && echo -e "  ${YELLOW}⏭  Skipped${NC}: ${skipped[*]}"
    [[ ${#failed[@]} -gt 0 ]] && echo -e "  ${RED}✗ Failed${NC}: ${failed[*]}"
    echo "═══════════════════════════════════════════════════════════"

    local key
    for key in ed25519 ecdsa rsa; do
        local pub="$SSH_DIR/id_${key}.pub"
        [[ -f "$pub" ]] && echo "  $key: $(ssh-keygen -lf "$pub" 2>/dev/null)"
    done

    _sync_ssh_config
    audit_log "INFO" "generate_ssh_key: gen=${generated[*]:-} skip=${skipped[*]:-} fail=${failed[*]:-}"
    [[ ${#failed[@]} -gt 0 ]] && return 1
    return 0
}

import_public_key() {
    read_servers; select_servers || return
    local idx ok=0 fail=0 total=${#SELECTED_INDICES[@]} n=0
    for idx in "${SELECTED_INDICES[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"
        info "[$n/$total] Import key ke $server ..."
        if ssh_copy_id_to_server "$server"; then ok=$((ok+1)); else fail=$((fail+1)); fi
    done
    echo ""
    info "Ringkasan: OK=$ok FAIL=$fail (dari $total)"
    audit_log "INFO" "import_key: ok=$ok fail=$fail"
}

test_passwordless() {
    read_servers; select_servers || return
    local idx ok=0 fail=0 total=${#SELECTED_INDICES[@]} n=0
    local fail_reasons=()
    for idx in "${SELECTED_INDICES[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"
        local reason
        reason=$(test_passwordless_one "$server" 2>&1)
        if (( $? == 0 )); then
            info "  ✓ Passwordless OK: $server"
            ok=$((ok+1))
        else
            warn "  ✗ FAILED: $server — $reason"
            fail=$((fail+1))
            fail_reasons+=("$server: $reason")
        fi
    done
    echo ""
    info "Ringkasan: OK=$ok FAIL=$fail (dari $total)"
    [[ ${#fail_reasons[@]} -gt 0 ]] && {
        echo "  Detail kegagalan:"
        local r; for r in "${fail_reasons[@]}"; do echo "    • $r"; done
    }
    audit_log "INFO" "test_passwordless: ok=$ok fail=$fail"
}

repair_ssh_key() {
    info "Repair local SSH permissions ..."
    mkdir -p "$SSH_DIR"; chmod 700 "$SSH_DIR"
    local key
    for key in ed25519 ecdsa rsa; do
        [[ -f "$SSH_DIR/id_$key" ]] && chmod 600 "$SSH_DIR/id_$key"
        [[ -f "$SSH_DIR/id_$key.pub" ]] && chmod 644 "$SSH_DIR/id_$key.pub"
    done
    [[ -f "$KNOWN_HOSTS" ]] && chmod 644 "$KNOWN_HOSTS"
    [[ -f "$SSH_DIR/config" ]] && chmod 600 "$SSH_DIR/config"
    info "Permissions repaired."
    info "Fingerprint TIDAK dihapus (gunakan list_remove untuk hapus eksplisit)."
    audit_log "INFO" "repair_ssh_key"
}

regenerate_ssh_key() {
    info "Regenerate semua SSH key ..."
    warn "Semua key lama akan DIGANTI (tanpa backup)."
    if ! confirm_destructive "Regenerate semua SSH key?" "REGENERATE_ALL_KEYS"; then
        info "Dibatalkan."; return 1
    fi
    local key
    for key in ed25519 ecdsa rsa; do
        rm -f "$SSH_DIR/id_$key" "$SSH_DIR/id_$key.pub"
    done
    generate_ssh_key
}

remove_ssh_key() {
    read_servers; select_servers || return
    if [[ ! -f "$SSH_DIR/id_rsa.pub" && ! -f "$SSH_DIR/id_ed25519.pub" ]]; then
        error "Public key tidak ada."; return 1
    fi
    local key_core
    if [[ -f "$SSH_DIR/id_ed25519.pub" ]]; then
        key_core=$(awk '{print $1" "$2}' "$SSH_DIR/id_ed25519.pub")
    else
        key_core=$(awk '{print $1" "$2}' "$SSH_DIR/id_rsa.pub")
    fi

    local idx ok=0 fail=0 total=${#SELECTED_INDICES[@]} n=0
    for idx in "${SELECTED_INDICES[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"
        local script
        script=$(cat <<'REMOTE'
#!/bin/bash
KEY="$KEY_CORE"
TARGET="$HOME/.ssh/authorized_keys"
[[ -f "$TARGET" ]] || { echo "OK: no authorized_keys"; exit 0; }
cp -a "$TARGET" "${TARGET}.bak.$(date +%Y%m%d%H%M%S)"
TMP=$(mktemp)
awk -v k="$KEY" 'index($0,k)==0' "$TARGET" > "$TMP"
cp "$TMP" "$TARGET"
chmod 600 "$TARGET"
rm -f "$TMP"
echo "OK: key removed"
echo "__RS_RESULT__: OK"
REMOTE
)
        if cel_remote_exec "$server" "Remove key" "$script" "KEY_CORE=$key_core"; then
            ok=$((ok+1))
        else
            fail=$((fail+1))
        fi
    done
    info "Ringkasan: OK=$ok FAIL=$fail (dari $total)"
    audit_log "INFO" "remove_ssh_key: ok=$ok fail=$fail"
}

ssh_key_management_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SSH KEY MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Setup Awal ---"
        echo "1. Generate SSH Keys (ed25519 + ecdsa + rsa)"
        echo "2. Import Public Keys (semua ke remote)"
        echo "3. Test Passwordless SSH"
        echo ""
        echo "--- Maintenance ---"
        echo "4. Regenerate SSH Keys"
        echo "5. Repair SSH Key (local permissions)"
        echo "6. Remove SSH Key (from remote)"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-6): "
        read -r c
        case "$c" in
            1) generate_ssh_key ;;
            2) import_public_key ;;
            3) test_passwordless ;;
            4) regenerate_ssh_key ;;
            5) repair_ssh_key ;;
            6) remove_ssh_key ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
