#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

service_status() {
    read_servers; select_servers || return
    read -rp "Service name (kosong = semua): " svc

    local script
    if [[ -z "$svc" ]]; then
        script='systemctl list-units --type=service --state=running 2>/dev/null; echo "__RS_RESULT__: OK"'
    else
        script="systemctl status $svc 2>/dev/null; echo \"__RS_RESULT__: OK\""
    fi
    run_action_on_servers_readonly "$script" "Service status"
}

service_stop() {
    read_servers; select_servers || return
    read -rp "Service: " svc
    [[ -z "$svc" ]] && return 1
    [[ ! "$svc" =~ ^[a-zA-Z0-9_.@-]+$ ]] && { error "Invalid service name"; return 1; }
    local script
    script=$(cat <<REMOTE
#!/bin/bash
\$SUDO systemctl stop $svc && echo "OK: stopped $svc" || { echo "__RS_ERROR__: gagal stop $svc" >&2; exit 1; }
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Stop $svc"
}

service_start() {
    read_servers; select_servers || return
    read -rp "Service: " svc
    [[ -z "$svc" ]] && return 1
    [[ ! "$svc" =~ ^[a-zA-Z0-9_.@-]+$ ]] && { error "Invalid service name"; return 1; }
    local script
    script=$(cat <<REMOTE
#!/bin/bash
\$SUDO systemctl start $svc && echo "OK: started $svc" || { echo "__RS_ERROR__: gagal start $svc" >&2; exit 1; }
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Start $svc"
}

service_restart() {
    read_servers; select_servers || return
    read -rp "Service: " svc
    [[ -z "$svc" ]] && return 1
    [[ ! "$svc" =~ ^[a-zA-Z0-9_.@-]+$ ]] && { error "Invalid service name"; return 1; }
    local script
    script=$(cat <<REMOTE
#!/bin/bash
\$SUDO systemctl restart $svc && echo "OK: restarted $svc" || { echo "__RS_ERROR__: gagal restart $svc" >&2; exit 1; }
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Restart $svc"
}

service_management_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SERVICE MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo "1. Service status"
        echo "2. Stop service"
        echo "3. Start service"
        echo "4. Restart service"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-4): "
        read -r c
        case "$c" in
            1) service_status ;;
            2) service_stop ;;
            3) service_start ;;
            4) service_restart ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
