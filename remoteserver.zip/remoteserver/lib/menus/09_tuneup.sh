#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

# ══════════════════════════════════════════════════════════════
# HELPER: DETEKSI SPESIFIKASI SERVER
# ══════════════════════════════════════════════════════════════
_get_server_specs() {
    local server="$1"
    local script='RAM=$(free -m | awk "/^Mem:/{print \$2}"); CPU=$(nproc 2>/dev/null || echo 1); echo "RAM=$RAM"; echo "CPU=$CPU"'
    local data=$(cel_remote_read "$server" "Get specs" "$script" 2>/dev/null)
    
    _SRV_RAM=$(echo "$data" | grep '^RAM=' | cut -d= -f2)
    _SRV_CPU=$(echo "$data" | grep '^CPU=' | cut -d= -f2)
    
    [[ -z "$_SRV_RAM" ]] && _SRV_RAM=1024
    [[ -z "$_SRV_CPU" ]] && _SRV_CPU=1
}

# ══════════════════════════════════════════════════════════════
# APACHE: AUTO TUNING (PROFILES)
# ══════════════════════════════════════════════════════════════
apache_auto_tune() {
    read_servers; select_servers || return
    local first_srv=$(get_server_by_index "${SELECTED_INDICES[0]}")
    
    info "Mendeteksi spesifikasi server & MPM Apache ..."
    _get_server_specs "$first_srv"
    
    # Deteksi MPM
    local detect_script=$(cat <<'REMOTE'
#!/bin/bash
if command -v apache2 >/dev/null 2>&1; then CTL="apache2ctl"; MODS="/etc/apache2/mods-enabled";
elif command -v httpd >/dev/null 2>&1; then CTL="apachectl"; MODS="/etc/httpd/conf.modules.d";
else echo "MPM=unknown"; exit 0; fi
MPM="unknown"
[ -d "$MODS" ] && for m in prefork worker event; do [ -L "$MODS/mpm_$m.load" ] && MPM="$m" && break; done
[ "$MPM" = "unknown" ] && MPM=$($CTL -V 2>/dev/null | grep -oP 'MPM: \K\w+' || echo "unknown")
echo "MPM=$MPM"
REMOTE
)
    local cur_mpm=$(cel_remote_read "$first_srv" "Detect MPM" "$detect_script" | grep '^MPM=' | cut -d= -f2)

    echo ""
    info "Spesifikasi: RAM=${_SRV_RAM}MB, CPU=${_SRV_CPU} Core, MPM=$cur_mpm"
    echo "Pilih Profil Auto-Tuning Apache:"
    echo "  1. Stability (Aman)     — Alokasi 60% RAM"
    echo "  2. Performance (Agresif)— Alokasi 85% RAM"
    read -rp "Pilih (1-2) [default 1]: " profile
    profile=${profile:-1}
    
    local ram_pct=60
    [[ "$profile" == "2" ]] && ram_pct=85

    confirm_action "Terapkan Auto-Tuning Apache (${ram_pct}% RAM)?" || return

    local script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if command -v apache2 >/dev/null 2>&1; then PKG="apache2"; MODS="/etc/apache2/mods-available"; SVC="apache2"; CTL="apache2ctl";
elif command -v httpd >/dev/null 2>&1; then PKG="httpd"; MODS="/etc/httpd/conf.modules.d"; SVC="httpd"; CTL="apachectl";
else echo "__RS_ERROR__: Apache not found" >&2; exit 1; fi

RAM=$(free -m | awk '/^Mem:/{print $2}'); CPU=$(nproc); [[ -z "$RAM" ]] && RAM=1024
MEM_PER_WORKER=30; [[ "$PROFILE" == "2" ]] && MEM_PER_WORKER=20

if [[ "$TARGET_MPM" == "prefork" ]]; then
    MAXW=$(( (RAM * RAM_PCT / 100) / MEM_PER_WORKER ))
    (( MAXW < 10 )) && MAXW=10; (( MAXW > 2000 )) && MAXW=2000
    cat <<EOT | $SUDO tee "$MODS/mpm_prefork.conf" >/dev/null
<IfModule mpm_prefork_module>
    StartServers         $(( CPU * 2 ))
    MinSpareServers      $(( CPU * 2 ))
    MaxSpareServers      $(( CPU * 4 ))
    MaxRequestWorkers    $MAXW
    MaxConnectionsPerChild 10000
</IfModule>
EOT
else
    MAXW=$(( (RAM * RAM_PCT / 100) / 50 ))
    (( MAXW < 25 )) && MAXW=25; (( MAXW > 10000 )) && MAXW=10000
    TPC=25; SL=$(( (MAXW + TPC - 1) / TPC ))
    cat <<EOT | $SUDO tee "$MODS/mpm_$TARGET_MPM.conf" >/dev/null
<IfModule mpm_${TARGET_MPM}_module>
    ServerLimit $SL; StartServers $(( CPU * 2 )); MinSpareThreads $(( CPU * 25 )); MaxSpareThreads $(( CPU * 75 ))
    ThreadsPerChild $TPC; MaxRequestWorkers $MAXW; MaxConnectionsPerChild 10000
</IfModule>
EOT
fi
$SUDO $CTL configtest >/dev/null 2>&1 && $SUDO systemctl restart "$SVC"
echo "OK: Apache Tuned (MaxWorkers=$MAXW, RAM_PCT=$RAM_PCT%)"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Auto-Tune Apache" \
        "TARGET_MPM=$cur_mpm" "PROFILE=$profile" "RAM_PCT=$ram_pct"
}

# ══════════════════════════════════════════════════════════════
# APACHE: ADVANCED TUNING (MANUAL)
# ══════════════════════════════════════════════════════════════
apache_advanced_tune() {
    read_servers; select_servers || return
    local first_srv=$(get_server_by_index "${SELECTED_INDICES[0]}")
    
    echo ""
    read -rp "Masukkan batas maksimal proses/worker (MaxRequestWorkers): " custom_workers
    validate_port "$custom_workers" || { error "Input harus angka valid"; return 1; }
    
    echo "Pilih MPM Target (Kosongkan untuk tidak mengubah):"
    echo "1. prefork  2. event  3. worker  0. Biarkan"
    read -rp "Pilih (0-3): " mpm_c
    
    local target_mpm=""
    case "$mpm_c" in 1) target_mpm="prefork";; 2) target_mpm="event";; 3) target_mpm="worker";; esac

    confirm_action "Terapkan Advanced Tuning Apache (Workers=$custom_workers)?" || return

    local script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if command -v apache2 >/dev/null 2>&1; then MODS="/etc/apache2/mods-available"; SVC="apache2"; CTL="apache2ctl"; ENABLED="/etc/apache2/mods-enabled";
elif command -v httpd >/dev/null 2>&1; then MODS="/etc/httpd/conf.modules.d"; SVC="httpd"; CTL="apachectl"; ENABLED="";
else echo "__RS_ERROR__: Apache not found" >&2; exit 1; fi
CPU=$(nproc)

# Ganti MPM jika diminta
if [[ -n "$TARGET_MPM" && "$TARGET_MPM" != "unknown" ]]; then
    if [ -d "$ENABLED" ]; then
        for m in prefork worker event; do [[ "$m" != "$TARGET_MPM" ]] && $SUDO a2dismod "mpm_$m" -f 2>/dev/null || true; done
        $SUDO a2enmod "mpm_$TARGET_MPM" -f 2>/dev/null || true
    fi
fi

# Deteksi MPM final
CUR_MPM="prefork"
if [ -d "$ENABLED" ]; then for m in prefork worker event; do [ -L "$ENABLED/mpm_$m.load" ] && CUR_MPM="$m"; done
else CUR_MPM=$($CTL -V 2>/dev/null | grep -oP 'MPM: \K\w+' || echo "prefork"); fi

if [[ "$CUR_MPM" == "prefork" ]]; then
    cat <<EOT | $SUDO tee "$MODS/mpm_prefork.conf" >/dev/null
<IfModule mpm_prefork_module>
    StartServers         $(( CPU * 2 ))
    MinSpareServers      $(( CPU * 2 ))
    MaxSpareServers      $(( CPU * 4 ))
    MaxRequestWorkers    $CUSTOM_WORKERS
    MaxConnectionsPerChild 10000
</IfModule>
EOT
else
    TPC=25; SL=$(( (CUSTOM_WORKERS + TPC - 1) / TPC ))
    cat <<EOT | $SUDO tee "$MODS/mpm_$CUR_MPM.conf" >/dev/null
<IfModule mpm_${CUR_MPM}_module>
    ServerLimit $SL; StartServers $(( CPU * 2 )); MinSpareThreads $(( CPU * 25 )); MaxSpareThreads $(( CPU * 75 ))
    ThreadsPerChild $TPC; MaxRequestWorkers $CUSTOM_WORKERS; MaxConnectionsPerChild 10000
</IfModule>
EOT
fi
$SUDO $CTL configtest >/dev/null 2>&1 && $SUDO systemctl restart "$SVC"
echo "OK: Apache Advanced Tuned (MPM=$CUR_MPM, Workers=$CUSTOM_WORKERS)"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Adv Tune Apache" \
        "TARGET_MPM=$target_mpm" "CUSTOM_WORKERS=$custom_workers"
}

# ══════════════════════════════════════════════════════════════
# NGINX: AUTO & ADVANCED TUNING
# ══════════════════════════════════════════════════════════════
nginx_auto_tune() {
    read_servers; select_servers || return
    echo ""
    echo "Pilih Profil Auto-Tuning Nginx:"
    echo "  1. Stability (Aman)"
    echo "  2. Performance (Agresif)"
    read -rp "Pilih (1-2) [default 1]: " profile
    profile=${profile:-1}
    confirm_action "Terapkan Auto-Tuning Nginx?" || return

    local script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
MEM=$(free -m | awk '/^Mem:/{print $2}'); CPU=$(nproc); [[ -z "$MEM" ]] && MEM=1024
CONF="/etc/nginx/nginx.conf"
[[ ! -f "$CONF" ]] && { echo "__RS_ERROR__: nginx.conf not found" >&2; exit 1; }
TS=$(date +%Y%m%d%H%M%S); $SUDO cp "$CONF" "${CONF}.bak.$TS"

CONN_FACTOR=2048; [[ "$PROFILE" == "2" ]] && CONN_FACTOR=1024
MAXCONN=$(( MEM * 1024 / CONN_FACTOR ))
(( MAXCONN < 1024 )) && MAXCONN=1024; (( MAXCONN > 65536 )) && MAXCONN=65536

$SUDO sed -i "s/^worker_processes.*/worker_processes $CPU;/" "$CONF"
$SUDO sed -i "s/^[[:space:]]*worker_connections.*/    worker_connections $MAXCONN;/" "$CONF"
$SUDO nginx -t >/dev/null 2>&1 && $SUDO systemctl restart nginx
echo "OK: Nginx Auto-Tuned (Connections=$MAXCONN)"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Auto-Tune Nginx" "PROFILE=$profile"
}

nginx_advanced_tune() {
    read_servers; select_servers || return
    echo ""
    read -rp "Masukkan jumlah worker_processes (contoh: 4): " custom_workers
    read -rp "Masukkan worker_connections (contoh: 8192): " custom_conn
    
    [[ "$custom_workers" =~ ^[0-9]+$ ]] || { error "Workers harus angka"; return 1; }
    [[ "$custom_conn" =~ ^[0-9]+$ ]] || { error "Connections harus angka"; return 1; }

    confirm_action "Terapkan Advanced Tuning Nginx (Workers=$custom_workers, Conn=$custom_conn)?" || return

    local script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
CONF="/etc/nginx/nginx.conf"
[[ ! -f "$CONF" ]] && { echo "__RS_ERROR__: nginx.conf not found" >&2; exit 1; }
TS=$(date +%Y%m%d%H%M%S); $SUDO cp "$CONF" "${CONF}.bak.$TS"

$SUDO sed -i "s/^worker_processes.*/worker_processes $CUSTOM_WORKERS;/" "$CONF"
$SUDO sed -i "s/^[[:space:]]*worker_connections.*/    worker_connections $CUSTOM_CONN;/" "$CONF"
$SUDO nginx -t >/dev/null 2>&1 && $SUDO systemctl restart nginx
echo "OK: Nginx Advanced Tuned (Workers=$CUSTOM_WORKERS, Conn=$CUSTOM_CONN)"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Adv Tune Nginx" \
        "CUSTOM_WORKERS=$custom_workers" "CUSTOM_CONN=$custom_conn"
}

# ══════════════════════════════════════════════════════════════
# DATABASE: AUTO & ADVANCED TUNING
# ══════════════════════════════════════════════════════════════
db_auto_tune() {
    read_servers; select_servers || return
    echo ""
    echo "Pilih Tipe Server Database:"
    echo "  1. Shared Server (Web + DB) — Alokasi 30-40% RAM"
    echo "  2. Dedicated DB Server      — Alokasi 70-80% RAM"
    read -rp "Pilih (1-2) [default 1]: " srv_type
    srv_type=${srv_type:-1}

    echo "Pilih Profil:"
    echo "  1. Stability (Aman)"
    echo "  2. Performance (Agresif)"
    read -rp "Pilih (1-2) [default 1]: " profile
    profile=${profile:-1}

    local ram_pct=35
    [[ "$srv_type" == "2" ]] && ram_pct=70
    [[ "$profile" == "2" ]] && ram_pct=$((ram_pct + 15))

    confirm_action "Terapkan Auto-Tuning DB (${ram_pct}% RAM)?" || return

    local script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
MEM=$(free -m | awk '/^Mem:/{print $2}'); [[ -z "$MEM" ]] && MEM=1024
ALLOC=$(( MEM * RAM_PCT / 100 ))

if command -v mysql >/dev/null 2>&1 || command -v mariadb >/dev/null 2>&1; then
    BUF=$ALLOC; (( BUF < 256 )) && BUF=256; (( BUF > 16384 )) && BUF=16384
    for CONF in /etc/mysql/my.cnf /etc/mysql/mariadb.conf.d/50-server.cnf /etc/my.cnf; do
        [[ ! -f "$CONF" ]] && continue
        TS=$(date +%Y%m%d%H%M%S); $SUDO cp "$CONF" "${CONF}.bak.$TS"
        $SUDO sed -i '/^innodb_buffer_pool_size/d' "$CONF"
        if grep -q "\[mysqld\]" "$CONF"; then $SUDO sed -i "/\[mysqld\]/a innodb_buffer_pool_size = ${BUF}M" "$CONF"
        else echo -e "\n[mysqld]\ninnodb_buffer_pool_size = ${BUF}M" | $SUDO tee -a "$CONF" >/dev/null; fi
        $SUDO systemctl restart mysql 2>/dev/null || $SUDO systemctl restart mariadb 2>/dev/null || true
        echo "OK: MySQL Buffer=${BUF}M"; break
    done
elif command -v psql >/dev/null 2>&1; then
    SHARED=$(( ALLOC * 70 / 100 )); (( SHARED < 128 )) && SHARED=128
    CONF=$(ls /etc/postgresql/*/main/postgresql.conf 2>/dev/null | head -1)
    if [[ -f "$CONF" ]]; then
        TS=$(date +%Y%m%d%H%M%S); $SUDO cp "$CONF" "${CONF}.bak.$TS"
        $SUDO sed -i "s/^shared_buffers.*/shared_buffers = ${SHARED}MB/" "$CONF"
        $SUDO systemctl restart postgresql 2>/dev/null || true
        echo "OK: PostgreSQL Shared_Buffers=${SHARED}MB"
    fi
else echo "__RS_ERROR__: No DB detected" >&2; exit 1; fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Auto-Tune DB" "RAM_PCT=$ram_pct"
}

db_advanced_tune() {
    read_servers; select_servers || return
    echo ""
    echo "Pilih Tipe Database:"
    echo "  1. MySQL/MariaDB (innodb_buffer_pool_size)"
    echo "  2. PostgreSQL (shared_buffers)"
    read -rp "Pilih (1-2): " db_type
    
    read -rp "Masukkan nilai memory (dalam MB, contoh: 1024): " custom_mem
    [[ "$custom_mem" =~ ^[0-9]+$ ]] || { error "Harus angka"; return 1; }

    confirm_action "Terapkan Advanced Tuning DB (${custom_mem}MB)?" || return

    local script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if [[ "$DB_TYPE" == "1" ]]; then
    for CONF in /etc/mysql/my.cnf /etc/mysql/mariadb.conf.d/50-server.cnf /etc/my.cnf; do
        [[ ! -f "$CONF" ]] && continue
        TS=$(date +%Y%m%d%H%M%S); $SUDO cp "$CONF" "${CONF}.bak.$TS"
        $SUDO sed -i '/^innodb_buffer_pool_size/d' "$CONF"
        if grep -q "\[mysqld\]" "$CONF"; then $SUDO sed -i "/\[mysqld\]/a innodb_buffer_pool_size = ${CUSTOM_MEM}M" "$CONF"
        else echo -e "\n[mysqld]\ninnodb_buffer_pool_size = ${CUSTOM_MEM}M" | $SUDO tee -a "$CONF" >/dev/null; fi
        $SUDO systemctl restart mysql 2>/dev/null || $SUDO systemctl restart mariadb 2>/dev/null || true
        echo "OK: MySQL Buffer=${CUSTOM_MEM}M"; break
    done
elif [[ "$DB_TYPE" == "2" ]]; then
    CONF=$(ls /etc/postgresql/*/main/postgresql.conf 2>/dev/null | head -1)
    if [[ -f "$CONF" ]]; then
        TS=$(date +%Y%m%d%H%M%S); $SUDO cp "$CONF" "${CONF}.bak.$TS"
        $SUDO sed -i "s/^shared_buffers.*/shared_buffers = ${CUSTOM_MEM}MB/" "$CONF"
        $SUDO systemctl restart postgresql 2>/dev/null || true
        echo "OK: PostgreSQL Shared_Buffers=${CUSTOM_MEM}MB"
    fi
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Adv Tune DB" \
        "DB_TYPE=$db_type" "CUSTOM_MEM=$custom_mem"
}

# ══════════════════════════════════════════════════════════════
# DATABASE REPAIR
# ══════════════════════════════════════════════════════════════
database_repair() {
    read_servers; select_servers || return
    warn "⚠️ Operasi ini mengunci tabel (Downtime)."
    warn "   • --optimize aman untuk semua tipe."
    warn "   • --repair HANYA untuk MyISAM (InnoDB tidak disarankan)."
    echo ""
    echo "1. Optimize  2. Repair  3. Both  0. Batal"
    read -rp "Pilih (0-3): " a
    local opt=""
    case "$a" in 1) opt="--optimize";; 2) opt="--repair";; 3) opt="--optimize --repair";; *) return 1;; esac
    confirm_destructive "Lanjutkan $opt?" "REPAIR_DB" || return

    local script=$(cat <<REMOTE
#!/bin/bash
command -v mysqlcheck >/dev/null 2>&1 || { echo "__RS_ERROR__: mysqlcheck not found" >&2; exit 1; }
echo "[*] Menjalankan mysqlcheck $opt --all-databases ..."
\$SUDO mysqlcheck $opt --all-databases 2>&1
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "DB Repair"
}

# ══════════════════════════════════════════════════════════════
# MENU UTAMA: SERVER TUNE-UP
# ══════════════════════════════════════════════════════════════
server_tune_up_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SERVER TUNE-UP & OPTIMIZATION"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- 1. AUTO TUNING (Profiles) ---"
        echo "1. Apache Auto-Tune (Stability / Performance)"
        echo "2. Nginx Auto-Tune (Stability / Performance)"
        echo "3. Database Auto-Tune (Shared / Dedicated)"
        echo ""
        echo "--- 2. ADVANCED TUNING (Custom Values) ---"
        echo "4. Apache Advanced Tune (Custom Workers)"
        echo "5. Nginx Advanced Tune (Custom Workers/Conn)"
        echo "6. Database Advanced Tune (Custom RAM MB)"
        echo ""
        echo "--- 3. MAINTENANCE ---"
        echo "7. Database Repair/Optimize"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-7): "
        read -r c
        case "$c" in
            1) apache_auto_tune ;;
            2) nginx_auto_tune ;;
            3) db_auto_tune ;;
            4) apache_advanced_tune ;;
            5) nginx_advanced_tune ;;
            6) db_advanced_tune ;;
            7) database_repair ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
