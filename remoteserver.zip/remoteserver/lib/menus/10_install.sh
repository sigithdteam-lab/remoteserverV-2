#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

install_apache_php() {
    confirm_action "Install Apache + PHP?" || return
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if [ -f /etc/debian_version ]; then
    $SUDO apt-get update -qq
    $SUDO apt-get install -y apache2 php libapache2-mod-php php-mysql php-cli php-curl php-zip php-gd php-mbstring php-xml
    $SUDO systemctl enable apache2 && $SUDO systemctl start apache2
elif [ -f /etc/redhat-release ]; then
    $SUDO yum install -y httpd php php-mysqlnd php-cli php-curl php-zip php-gd php-mbstring php-xml
    $SUDO systemctl enable httpd && $SUDO systemctl start httpd
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Install Apache+PHP"
}

install_nginx_php() {
    confirm_action "Install Nginx + PHP-FPM?" || return
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if [ -f /etc/debian_version ]; then
    $SUDO apt-get update -qq
    $SUDO apt-get install -y nginx php-fpm php-mysql php-cli php-curl php-zip php-gd php-mbstring php-xml
    $SUDO systemctl enable nginx php-fpm && $SUDO systemctl start nginx php-fpm
elif [ -f /etc/redhat-release ]; then
    $SUDO yum install -y epel-release
    $SUDO yum install -y nginx php-fpm php-mysqlnd php-cli php-curl php-zip php-gd php-mbstring php-xml
    $SUDO systemctl enable nginx php-fpm && $SUDO systemctl start nginx php-fpm
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Install Nginx+PHP"
}

install_mariadb() {
    confirm_action "Install MariaDB?" || return
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if [ -f /etc/debian_version ]; then
    $SUDO apt-get update -qq
    $SUDO apt-get install -y mariadb-server mariadb-client
    $SUDO systemctl enable mariadb && $SUDO systemctl start mariadb
elif [ -f /etc/redhat-release ]; then
    $SUDO yum install -y mariadb-server mariadb
    $SUDO systemctl enable mariadb && $SUDO systemctl start mariadb
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Install MariaDB"
}

install_postgresql() {
    confirm_action "Install PostgreSQL?" || return
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if ! command -v psql >/dev/null 2>&1; then
    echo "[*] Menginstal PostgreSQL ..."
    if [ -f /etc/debian_version ]; then
        $SUDO apt-get update -qq
        $SUDO apt-get install -y postgresql postgresql-contrib -qq
        $SUDO systemctl enable postgresql && $SUDO systemctl start postgresql
    elif [ -f /etc/redhat-release ]; then
        $SUDO yum install -y postgresql-server postgresql-contrib -q
        $SUDO postgresql-setup --initdb 2>/dev/null || true
        $SUDO systemctl enable postgresql && $SUDO systemctl start postgresql
    fi
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Install PostgreSQL"
}

install_lamp() {
    confirm_action "Install LAMP (Apache + PHP + MariaDB)?" || return
    install_apache_php
    install_mariadb
}

install_lemp() {
    confirm_action "Install LEMP (Nginx + PHP-FPM + MariaDB)?" || return
    install_nginx_php
    install_mariadb
}

install_lepp() {
    confirm_action "Install LEPP (Nginx + PHP-FPM + PostgreSQL)?" || return
    install_nginx_php
    install_postgresql
}

# ── Farm Server Management
farm_server_management_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  FARM SERVER MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo ""
        echo "1. True High Availability (HA)"
        echo "   • 2 HAProxy Server"
        echo "   • Keepalived / VRRP"
        echo "   • Virtual IP (VIP)"
        echo "   • Automatic Failover"
        echo "   • 2 Web Server"
        echo "   • Database Server"
        echo "   • NFS Shared Storage"
        echo ""
        echo "2. Simple Load Balancer"
        echo "   • 1 HAProxy Server"
        echo "   • 2 Web Server"
        echo "   • Database Server"
        echo "   • NFS Shared Storage"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-2): "
        read -r c
        case "$c" in
            1) install_farm_true_ha ;;
            2) install_farm_simple_lb ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}

install_farm_simple_lb() {
    echo ""
    warn "Simple Load Balancer (BUKAN HA)"
    warn "  • Single HAProxy = SPOF (jika mati, aplikasi down)"
    warn "  • Single DB/NFS = SPOF"
    confirm_action "Lanjutkan?" || return

    read -rp "HAProxy (user@ip): " lb_in
    read -rp "Web1 (user@ip): " web1_in
    read -rp "Web2 (user@ip): " web2_in
    read -rp "Database (user@ip): " db_in
    read -rp "NFS (user@ip): " fs_in

    for input in "$lb_in" "$web1_in" "$web2_in" "$db_in" "$fs_in"; do
        parse_server_string "$input" || { error "Invalid: $input"; return 1; }
    done

    parse_server_string "$web1_in"; local web1_ip="$_S_HOST"
    parse_server_string "$web2_in"; local web2_ip="$_S_HOST"
    parse_server_string "$db_in";   local db_ip="$_S_HOST"
    parse_server_string "$fs_in";   local fs_ip="$_S_HOST"

    info "Installing NFS di $fs_in ..."
    local nfs_script
    nfs_script=$(cat <<REMOTE
#!/bin/bash
set -uo pipefail

if ! command -v exportfs >/dev/null 2>&1; then
    echo "[*] Menginstal NFS Server ..."
    if [ -f /etc/debian_version ]; then
        \$SUDO apt-get update -qq && \$SUDO apt-get install -y nfs-kernel-server -qq
    elif [ -f /etc/redhat-release ]; then
        \$SUDO yum install -y nfs-utils -q && \$SUDO systemctl enable nfs-server && \$SUDO systemctl start nfs-server
    fi
fi

mkdir -p /srv/nfs/shared
chown nobody:nogroup /srv/nfs/shared 2>/dev/null || chown nobody:nobody /srv/nfs/shared
chmod 755 /srv/nfs/shared
TS=\$(date +%Y%m%d%H%M%S)
[[ -f /etc/exports ]] && \$SUDO cp /etc/exports /etc/exports.bak.\$TS
echo "/srv/nfs/shared ${web1_ip}/32(rw,sync,no_subtree_check,root_squash,all_squash)" | \$SUDO tee -a /etc/exports
echo "/srv/nfs/shared ${web2_ip}/32(rw,sync,no_subtree_check,root_squash,all_squash)" | \$SUDO tee -a /etc/exports
\$SUDO exportfs -ra
\$SUDO systemctl restart nfs-server 2>/dev/null || \$SUDO systemctl restart nfs-kernel-server 2>/dev/null || true
echo "OK: NFS configured"
echo "__RS_RESULT__: OK"
REMOTE
)
    cel_remote_exec "$fs_in" "Install NFS" "$nfs_script" || { error "NFS gagal"; return 1; }

    info "Installing DB di $db_in ..."
    install_postgresql
}

install_farm_true_ha() {
    echo ""
    warn "True High Availability (butuh 9 server + VIP)"
    warn "Membutuhkan persiapan preflight (VIP, Keepalived, VRRP)."
    echo ""
    echo "Masukkan IP (Kosongkan untuk simulasi):"
    read -rp "  HAProxy 1 (MASTER): " lb1
    read -rp "  HAProxy 2 (BACKUP): " lb2
    read -rp "  VIP               : " vip
    
    if [[ -z "$lb1" || -z "$lb2" || -z "$vip" ]]; then
        warn "Input tidak lengkap. Kembali ke menu."
        return 1
    fi
    
    info "Menyiapkan True HA (simulasi konsep)..."
    info "  1. Konfigurasi VRRP di $lb1 (MASTER) dan $lb2 (BACKUP)"
    info "  2. Virtual IP: $vip"
    info "  3. Menguji failover..."
    echo ""
    info "Catatan: Alur instalasi lengkap True HA membutuhkan setup multi-server."
    info "Saat ini fitur True HA baru sebatas info. Gunakan Simple LB untuk implementasi nyata."
    echo ""
    read -rp "Tekan Enter untuk kembali..."
}

# ══════════════════════════════════════════════════════════════
# MENU UTAMA INSTALASI (DENGAN PEMISAHAN KATEGORI)
# ══════════════════════════════════════════════════════════════
instalasi_server_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  INSTALASI SERVER MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Komponen Tunggal ---"
        echo "1. Install Apache + PHP"
        echo "2. Install Nginx + PHP-FPM"
        echo "3. Install MariaDB"
        echo "4. Install PostgreSQL"
        echo ""
        echo "--- Stack (Gabungan) ---"
        echo "5. Install LAMP (Apache + PHP + MariaDB)"
        echo "6. Install LEMP (Nginx + PHP-FPM + MariaDB)"
        echo "7. Install LEPP (Nginx + PHP-FPM + PostgreSQL)"
        echo ""
        echo "--- Advanced ---"
        echo "8. Farm Server Management"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-8): "
        read -r c
        case "$c" in
            1) install_apache_php ;;
            2) install_nginx_php ;;
            3) install_mariadb ;;
            4) install_postgresql ;;
            5) install_lamp ;;
            6) install_lemp ;;
            7) install_lepp ;;
            8) farm_server_management_menu ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
