#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

build_maintenance_script() {
    local debian="$1" rhel="$2"
    cat <<EOS
#!/bin/bash
if [ "\$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo -n"; fi
if [ -f /etc/debian_version ]; then
$debian
elif [ -f /etc/redhat-release ]; then
$rhel
else
    echo "__RS_ERROR__: OS tidak didukung" >&2
    exit 1
fi
echo "__RS_RESULT__: OK"
EOS
}

maintain_pending_updates() {
    local s
    s=$(build_maintenance_script \
'    N=$($SUDO apt-get --just-print upgrade 2>/dev/null | grep -cE "^Inst" || echo 0)
    echo "Pending updates: $N"' \
'    N=$($SUDO yum check-update 2>/dev/null | grep -cE "^[a-zA-Z0-9]" || echo 0)
    echo "Pending updates: $N"')
    run_action_on_servers_readonly "$s" "Check pending updates"
}

maintain_check_reboot() {
    local s
    s=$(cat <<'EOS'
#!/bin/bash
if [ -f /var/run/reboot-required ]; then
    echo "Reboot required: YES"
else
    echo "Reboot required: NO"
fi
echo "__RS_RESULT__: OK"
EOS
)
    run_action_on_servers_readonly "$s" "Check pending reboot"
}

maintain_update() {
    local s
    s=$(build_maintenance_script \
        '    $SUDO apt-get update' \
        '    $SUDO yum check-update || true')
    run_action_on_servers_privileged "$s" "Update package lists"
}

maintain_upgrade() {
    local s
    s=$(build_maintenance_script \
        '    $SUDO apt-get upgrade -y' \
        '    $SUDO yum update -y')
    run_action_on_servers_privileged "$s" "Upgrade packages"
}

maintain_update_upgrade() {
    local s
    s=$(build_maintenance_script \
        '    $SUDO apt-get update && $SUDO apt-get upgrade -y' \
        '    $SUDO yum check-update || true && $SUDO yum update -y')
    run_action_on_servers_privileged "$s" "Update & Upgrade"
}

maintain_repair_packages() {
    local s
    s=$(build_maintenance_script \
        '    $SUDO dpkg --configure -a
    $SUDO apt --fix-broken install -y || true
    $SUDO apt autoremove -y || true
    $SUDO apt autoclean || true' \
        '    $SUDO rpm --rebuilddb
    $SUDO yum clean all
    $SUDO yum-complete-transaction 2>/dev/null || true')
    run_action_on_servers_privileged "$s" "Repair package management"
}

maintain_clean_all() {
    local s
    s=$(cat <<'EOS'
#!/bin/bash
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo -n"; fi
echo "─── Clean All (SAFE) ───"

echo "[1] Package cache"
if command -v apt-get >/dev/null 2>&1; then
    $SUDO apt-get clean
    $SUDO apt-get autoclean
elif command -v yum >/dev/null 2>&1; then
    $SUDO yum clean all
elif command -v dnf >/dev/null 2>&1; then
    $SUDO dnf clean all
fi

echo "[2] Memory cache"
sync
echo 3 | $SUDO tee /proc/sys/vm/drop_caches >/dev/null 2>&1 || echo "WARN: drop_caches gagal"

echo "[3] Journal"
if command -v journalctl >/dev/null 2>&1; then
    $SUDO journalctl --vacuum-size=100M --vacuum-time=30d 2>&1 | tail -3
fi

echo "__RS_RESULT__: OK"
EOS
)
    run_action_on_servers_privileged "$s" "Clean All (Safe)"
}

maintain_deep_clean_dryrun() {
    local s
    s=$(cat <<'EOS'
#!/bin/bash
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo -n"; fi
echo "─── Deep Clean (DRY-RUN) ───"

show_files() {
    local desc="$1" pattern="$2" path="$3" mtime="$4" maxdepth="${5:-2}"
    echo ""
    echo "[$desc]"
    [[ ! -d "$path" ]] && { echo "  SKIP: $path tidak ada"; return; }
    local total=0 count=0
    while IFS= read -r -d '' f; do
        size=$(stat -c%s "$f" 2>/dev/null || echo 0)
        total=$((total + size))
        count=$((count + 1))
        echo "  [will delete] $f ($size bytes)"
    done < <(find "$path" -maxdepth "$maxdepth" -type f $pattern -mtime +"$mtime" -print0 2>/dev/null)
    echo "  Total: $count file, $total bytes"
}

show_files "Log rotasi > 14 hari" "-name *.gz -o -name *.xz" "/var/log" 14 2
show_files "Log > 14 hari" "-name *.log" "/var/log" 14 1

echo ""
echo "__RS_RESULT__: OK (dry-run)"
EOS
)
    run_action_on_servers_readonly "$s" "Deep Clean (dry-run)"
}

maintain_deep_clean() {
    read_servers; select_servers || return
    warn "Deep Clean akan MENGHAPUS log lama."
    confirm_destructive "Lanjutkan Deep Clean?" "DEEP_CLEAN" || return

    local s
    s=$(cat <<'EOS'
#!/bin/bash
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo -n"; fi
echo "─── Deep Clean (REAL) ───"
DELETED=0

if [[ -d /var/log ]]; then
    N=$(find /var/log -maxdepth 2 -type f \( -name "*.gz" -o -name "*.xz" \) -mtime +14 2>/dev/null | wc -l)
    $SUDO find /var/log -maxdepth 2 -type f \( -name "*.gz" -o -name "*.xz" \) -mtime +14 -delete 2>/dev/null
    DELETED=$((DELETED + N))
    echo "  [log rotation] removed $N files"
fi

if [[ -d /var/log ]]; then
    N=0
    while IFS= read -r -d '' f; do
        $SUDO truncate -s 0 "$f" 2>/dev/null && N=$((N+1))
    done < <(find /var/log -maxdepth 1 -type f -name "*.log" \( -size +100M -o -mtime +14 \) -print0 2>/dev/null)
    DELETED=$((DELETED + N))
    echo "  [large logs] truncated $N files"
fi

echo "TOTAL DELETED: $DELETED"
echo "__RS_RESULT__: OK"
EOS
)
    run_action_on_servers_privileged "$s" "Deep Clean"
}

server_maintainer_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SERVER MAINTAINER"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Audit ---"
        echo "1. Check pending updates"
        echo "2. Check pending reboot"
        echo ""
        echo "--- Package Update ---"
        echo "3. Update package lists"
        echo "4. Upgrade packages"
        echo "5. Update & Upgrade"
        echo "6. Repair package management"
        echo ""
        echo "--- Cleanup ---"
        echo "7. Clean All (SAFE)"
        echo "8. Deep Clean (dry-run preview)"
        echo "9. Deep Clean (REAL)"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-9): "
        read -r c
        case "$c" in
            1) maintain_pending_updates ;;
            2) maintain_check_reboot ;;
            3) maintain_update ;;
            4) maintain_upgrade ;;
            5) maintain_update_upgrade ;;
            6) maintain_repair_packages ;;
            7) maintain_clean_all ;;
            8) maintain_deep_clean_dryrun ;;
            9) maintain_deep_clean ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
