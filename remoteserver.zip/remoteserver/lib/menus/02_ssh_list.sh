#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

list_show() {
    read_servers
    if [[ ${#SERVERS_CACHED[@]} -eq 0 ]]; then info "List kosong."; return; fi
    echo "═══════════════════════════════════════════════════════════"
    echo "  LIST SERVER ($SERVER_LIST)"
    echo "═══════════════════════════════════════════════════════════"
    local i
    for i in "${!SERVERS_CACHED[@]}"; do
        printf "  %3d) %s\n" "$((i+1))" "${SERVERS_CACHED[$i]}"
    done
    echo "═══════════════════════════════════════════════════════════"
    echo "  Total: ${#SERVERS_CACHED[@]} server"
}

list_add() {
    echo "Format: user@host[:port] atau host[:port]"
    read -rp "Server baru: " new_server
    new_server="${new_server#"${new_server%%[![:space:]]*}"}"
    new_server="${new_server%"${new_server##*[![:space:]]}"}"
    [[ -z "$new_server" ]] && { error "Kosong."; return 1; }
    if ! parse_server_string "$new_server"; then
        error "Format tidak valid: $_S_ERROR"; return 1
    fi
    read_servers
    local existing
    for existing in "${SERVERS_CACHED[@]}"; do
        [[ "$existing" == "$new_server" ]] && { error "Sudah ada."; return 1; }
    done
    backup_with_retention "$SERVER_LIST"
    [[ -s "$SERVER_LIST" && "$(tail -c1 "$SERVER_LIST")" != "" ]] && echo "" >> "$SERVER_LIST"
    echo "$new_server" >> "$SERVER_LIST"
    refresh_servers
    info "Ditambahkan: $new_server"
    audit_log "INFO" "list_add: $new_server"
    _sync_ssh_config

    if [[ -f "$SSH_DIR/id_ed25519.pub" || -f "$SSH_DIR/id_rsa.pub" ]]; then
        echo -n "Import key sekarang? (Y/n): "
        read -r -n 1 ans; echo
        [[ ! "$ans" =~ ^[Nn]$ ]] && ssh_copy_id_to_server "$new_server"
    fi
}

list_remove() {
    read_servers
    [[ ${#SERVERS_CACHED[@]} -eq 0 ]] && { info "Kosong."; return 1; }
    list_show
    echo ""
    read -rp "Nomor (1,2 / 1-3 / all): " sel

    local -a to_remove=()
    if [[ "$sel" =~ ^[0-9]+$ ]]; then
        to_remove=("$sel")
    elif [[ "$sel" =~ ^([0-9]+)-([0-9]+)$ ]]; then
        local a="${BASH_REMATCH[1]}" b="${BASH_REMATCH[2]}"
        (( a <= b )) && for ((i=a; i<=b; i++)); do to_remove+=("$i"); done
    elif [[ "$sel" == "all" ]]; then
        local i
        for i in "${!SERVERS_CACHED[@]}"; do to_remove+=("$((i+1))"); done
    else
        error "Tidak valid."; return 1
    fi

    local -a removed_servers=()
    local idx
    for idx in "${to_remove[@]}"; do
        (( idx >= 1 && idx <= ${#SERVERS_CACHED[@]} )) && \
            removed_servers+=("${SERVERS_CACHED[$((idx-1))]}")
    done

    echo ""
    echo "Akan hapus:"
    local s
    for s in "${removed_servers[@]}"; do echo "  • $s"; done
    confirm_destructive "Hapus ${#removed_servers[@]} server?" "DELETE" || return 1

    backup_with_retention "$SERVER_LIST"
    local tmp; tmp=$(mktemp); register_temp_file "$tmp"
    local i
    for i in "${!SERVERS_CACHED[@]}"; do
        local n=$((i+1)); local skip=false; local r
        for r in "${to_remove[@]}"; do [[ "$n" == "$r" ]] && { skip=true; break; }; done
        [[ "$skip" == "false" ]] && echo "${SERVERS_CACHED[$i]}" >> "$tmp"
    done
    mv "$tmp" "$SERVER_LIST"
    refresh_servers
    info "Sisa: ${#SERVERS_CACHED[@]} server."
    audit_log "INFO" "list_remove: ${#removed_servers[@]} server"

    for s in "${removed_servers[@]}"; do
        parse_server_string "$s" || continue
        local kh_key; kh_key=$(_known_hosts_key)
        if [[ -f "$KNOWN_HOSTS" ]]; then
            backup_with_retention "$KNOWN_HOSTS"
            ssh-keygen -R "$kh_key" -f "$KNOWN_HOSTS" >/dev/null 2>&1 || true
            rm -f "${KNOWN_HOSTS}.old" 2>/dev/null || true
            info "  known_hosts: removed $kh_key"
        fi
    done
    _sync_ssh_config
}

list_verify() {
    read_servers
    echo "═══════════════════════════════════════════════════════════"
    echo "  VERIFIKASI KONSISTENSI"
    echo "═══════════════════════════════════════════════════════════"
    local s
    for s in "${SERVERS_CACHED[@]}"; do
        parse_server_string "$s" || continue
        local in_kh="no"
        if [[ -f "$KNOWN_HOSTS" ]]; then
            local kh_key; kh_key=$(_known_hosts_key)
            ssh-keygen -F "$kh_key" -f "$KNOWN_HOSTS" >/dev/null 2>&1 && in_kh="yes"
        fi
        printf "  %-40s known_hosts=%s\n" "$s" "$in_kh"
    done
    echo "═══════════════════════════════════════════════════════════"
}

remote_ssh_manual() {
    read -rp "Server (user@host[:port] atau host[:port]): " s
    [[ -z "$s" ]] && { error "Kosong."; return; }
    if ! parse_server_string "$s"; then
        error "Format tidak valid: $_S_ERROR"; return 1
    fi
    local target; target=$(_ssh_target)
    local -a opts; mapfile -t opts < <(build_ssh_opts "$_S_PORT")
    ssh "${opts[@]}" "$target"
}

remote_ssh_from_list() {
    read_servers; select_servers || return
    local idx
    for idx in "${SELECTED_INDICES[@]}"; do
        local server; server=$(get_server_by_index "$idx")
        info "Connecting to $server ..."
        if parse_server_string "$server"; then
            local target; target=$(_ssh_target)
            local -a opts; mapfile -t opts < <(build_ssh_opts "$_S_PORT")
            ssh "${opts[@]}" "$target"
        fi
        echo "--- Disconnected: $server ---"
    done
}

ssh_management_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SSH & SERVER LIST MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Server List ---"
        echo "1. Lihat list server"
        echo "2. Tambah server"
        echo "3. Hapus server (cleanup auth lokal)"
        echo "4. Verifikasi konsistensi"
        echo ""
        echo "--- Koneksi ---"
        echo "5. Remote SSH (manual)"
        echo "6. Remote SSH (from list)"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-6): "
        read -r c
        case "$c" in
            1) list_show ;;
            2) list_add ;;
            3) list_remove ;;
            4) list_verify ;;
            5) remote_ssh_manual ;;
            6) remote_ssh_from_list ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
