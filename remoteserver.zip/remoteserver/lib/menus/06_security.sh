#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

sec_firewall_status() {
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
if command -v ufw >/dev/null 2>&1; then
    if systemctl is-active --quiet ufw 2>/dev/null; then
        echo "UFW: active"
        sudo -n ufw status verbose 2>/dev/null || echo "(butuh sudo -n untuk detail)"
    else
        echo "UFW: inactive"
    fi
elif command -v firewall-cmd >/dev/null 2>&1; then
    if systemctl is-active --quiet firewalld 2>/dev/null; then
        echo "firewalld: active"
    else
        echo "firewalld: inactive"
    fi
else
    echo "No firewall detected (ufw/firewalld)"
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_readonly "$script" "Firewall status"
}

sec_open_ports() {
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
echo "── Listening ports ──"
if [ "$(id -u)" -eq 0 ]; then
    ss -tulpn 2>/dev/null | grep LISTEN
else
    ss -tulpn 2>/dev/null | grep LISTEN || netstat -tulpn 2>/dev/null | grep LISTEN
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_readonly "$script" "Open ports"
}

sec_failed_logins() {
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
echo "── Recent failed logins ──"
if command -v lastb >/dev/null 2>&1; then
    lastb -n 10 2>/dev/null | head -10 || echo "(lastb butuh root)"
fi
echo ""
if [[ -f /var/log/auth.log ]]; then
    grep "Failed password" /var/log/auth.log 2>/dev/null | tail -10 || echo "(tidak ada)"
elif [[ -f /var/log/secure ]]; then
    grep "Failed password" /var/log/secure 2>/dev/null | tail -10 || echo "(tidak ada)"
fi
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_readonly "$script" "Failed logins"
}

sec_firewall_add_rule() {
    echo ""
    echo "Pilih jenis rule:"
    echo "  1. Allow port"
    echo "  2. Drop IP"
    echo "  3. Reject IP"
    echo "  0. Batal"
    read -rp "Pilih (0-3): " t

    case "$t" in
        1)
            read -rp "Port (1-65535): " port
            validate_port "$port" || { error "Port tidak valid"; return 1; }
            read -rp "Protocol (tcp/udp): " proto
            [[ "$proto" =~ ^(tcp|udp)$ ]] || { error "Proto tidak valid"; return 1; }
            local script
            script=$(cat <<REMOTE
#!/bin/bash
if command -v ufw >/dev/null 2>&1; then
    \$SUDO ufw allow $port/$proto
elif command -v firewall-cmd >/dev/null 2>&1; then
    \$SUDO firewall-cmd --add-port=$port/$proto --permanent && \$SUDO firewall-cmd --reload
fi
echo "OK: allow $port/$proto"
echo "__RS_RESULT__: OK"
REMOTE
)
            run_action_on_servers_privileged "$script" "Allow $port/$proto"
            ;;
        2|3)
            read -rp "IP: " ip
            validate_ip "$ip" || { error "IP tidak valid"; return 1; }
            local action=$([ "$t" -eq 2 ] && echo "drop" || echo "reject")
            local script
            script=$(cat <<REMOTE
#!/bin/bash
if command -v ufw >/dev/null 2>&1; then
    \$SUDO ufw $action from $ip
elif command -v firewall-cmd >/dev/null 2>&1; then
    \$SUDO firewall-cmd --permanent --add-rich-rule="rule family='ipv4' source address='$ip' $action"
    \$SUDO firewall-cmd --reload
fi
echo "OK: $action $ip"
echo "__RS_RESULT__: OK"
REMOTE
)
            run_action_on_servers_privileged "$script" "$action $ip"
            ;;
        *) return 1 ;;
    esac
}

sec_virus_scan() {
    echo ""
    echo "Folder (path absolut, multiple dengan koma):"
    read -rp "Folder: " folders_input
    [[ -z "${folders_input// }" ]] && { error "Kosong."; return 1; }

    local -a folders=()
    IFS=',' read -ra raw <<< "$folders_input"
    local f
    for f in "${raw[@]}"; do
        f="${f#"${f%%[![:space:]]*}"}"
        f="${f%"${f##*[![:space:]]}"}"
        [[ -z "$f" ]] && continue
        validate_scan_path "$f" || return 1
        folders+=("$f")
    done
    [[ ${#folders[@]} -eq 0 ]] && { error "Tidak ada folder valid."; return 1; }

    echo ""
    echo "Mode:"
    echo "  1. Scan only (default)"
    echo "  2. Scan + HAPUS infected (DESTRUKTIF)"
    echo "  0. Batal"
    read -rp "Pilih (0-2) [default 1]: " scan_mode

    local mode_flag=""
    case "${scan_mode:-1}" in
        1) mode_flag="" ;;
        2)
            mode_flag="--remove"
            error "⚠️  MODE --remove: file terinfeksi akan DIHAPUS."
            confirm_destructive "Hapus file terinfeksi?" "REMOVE_INFECTED" || return 1
            ;;
        *) return 1 ;;
    esac

    local folders_json
    folders_json=$(printf '%s\n' "${folders[@]}" | jq -R . | jq -s .)

    # Memanggil script terpisah dari lib/remote_scripts/
    local script_file="$LIB_DIR/remote_scripts/clamav_scan.sh"
    [[ ! -f "$script_file" ]] && { error "Script ClamAV tidak ditemukan: $script_file"; return 1; }
    
    local script
    script=$(cat "$script_file")

    run_action_on_servers_privileged "$script" "ClamAV scan" \
        "FOLDERS_JSON=$folders_json" "MODE_FLAG=$mode_flag"
}

security_management_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SECURITY MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Audit ---"
        echo "1. Firewall status"
        echo "2. Open ports"
        echo "3. Failed logins"
        echo ""
        echo "--- Firewall Action ---"
        echo "4. Firewall add rule"
        echo ""
        echo "--- Additional ---"
        echo "5. Virus scan (ClamAV)"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-5): "
        read -r c
        case "$c" in
            1) sec_firewall_status ;;
            2) sec_open_ports ;;
            3) sec_failed_logins ;;
            4) sec_firewall_add_rule ;;
            5) sec_virus_scan ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
