#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

# ══════════════════════════════════════════════════════════════
# USER MANAGEMENT
# ══════════════════════════════════════════════════════════════

user_list() {
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
echo "════════════════════════════════════════"
echo "  HUMAN USERS (UID >= 1000)"
echo "════════════════════════════════════════"
printf "%-20s %-8s %-25s\n" "username" "uid" "groups"
getent passwd 2>/dev/null | awk -F: '$3>=1000 && $3<65534 {print $1":"$3}' | while IFS=: read -r u uid; do
    grps=$(id -Gn "$u" 2>/dev/null | tr ' ' ',')
    printf "%-20s %-8s %-25s\n" "$u" "$uid" "$grps"
done
echo ""
echo "════════════════════════════════════════"
echo "  SYSTEM USERS (UID < 1000)"
echo "════════════════════════════════════════"
getent passwd 2>/dev/null | awk -F: '$3<1000 && $3>0 {print $1":"$3}' | head -20
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_readonly "$script" "User list"
}

user_add() {
    echo ""
    read -rp "Username baru: " username
    [[ -z "$username" ]] && { error "Kosong."; return 1; }
    if [[ ! "$username" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
        error "Username tidak valid: '$username'"; return 1
    fi
    read -rsp "Password: " pw1; echo
    read -rsp "Confirm: " pw2; echo
    [[ "$pw1" != "$pw2" ]] && { error "Tidak sama."; return 1; }
    [[ ${#pw1} -lt 8 ]] && { error "Minimal 8 karakter."; return 1; }

    if ! confirm_action "Tambah user '$username'?"; then return 1; fi

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
[[ "$USERNAME" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]] || { echo "__RS_ERROR__: username invalid" >&2; exit 1; }
[[ -z "${PASSWORD:-}" ]] && { echo "__RS_ERROR__: password kosong" >&2; exit 1; }

if id "$USERNAME" &>/dev/null; then
    echo "__RS_ERROR__: user sudah ada" >&2
    exit 1
fi

$SUDO useradd -m -s /bin/bash "$USERNAME"
echo "$USERNAME:$PASSWORD" | $SUDO chpasswd
$SUDO passwd -e "$USERNAME" >/dev/null 2>&1 || true

echo "OK: user $USERNAME dibuat"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Add user $username" \
        "USERNAME=$username" "PASSWORD=$pw1"
}

user_delete_protected() {
    read_servers; select_servers || return
    read -rp "Username yang akan dihapus: " username
    [[ -z "$username" ]] && { error "Kosong."; return 1; }
    if [[ ! "$username" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
        error "Username tidak valid: '$username'"; return 1
    fi

    info "Mengumpulkan info user '$username' ..."
    echo ""

    local check_script
    check_script=$(cat <<'REMOTE'
#!/bin/bash
if ! id "$USERNAME" &>/dev/null; then
    echo "STATUS=NOT_EXIST"; exit 0
fi
uid=$(id -u "$USERNAME")
current_user=$(id -un)
if [[ "$uid" -eq 0 ]]; then
    echo "STATUS=BLOCKED"; echo "REASON=UID_0 (root)"; echo "UID=$uid"; exit 0
fi
if [[ "$uid" -lt 1000 ]]; then
    echo "STATUS=BLOCKED"; echo "REASON=SYSTEM_ACCOUNT (UID=$uid < 1000)"; echo "UID=$uid"; exit 0
fi
if [[ "$username" == "$current_user" ]]; then
    echo "STATUS=BLOCKED"; echo "REASON=CURRENT_SSH_USER"; echo "UID=$uid"; exit 0
fi
if command -v who >/dev/null 2>&1 && who 2>/dev/null | grep -qw "$USERNAME"; then
    echo "STATUS=BLOCKED"; echo "REASON=ACTIVE_SESSION"; echo "UID=$uid"; exit 0
fi
echo "STATUS=ALLOWED"
echo "UID=$uid"
echo "HOME=$(getent passwd "$USERNAME" | cut -d: -f6)"
echo "GROUPS=$(id -Gn "$USERNAME" 2>/dev/null)"
echo "PROCESS_COUNT=$(ps -u "$USERNAME" -o pid= 2>/dev/null | wc -l)"
echo "__RS_RESULT__: OK"
REMOTE
)

    local -a blocked_servers=()
    local -a allowed_servers=()
    local idx n=0 total=${#SELECTED_INDICES[@]}
    for idx in "${SELECTED_INDICES[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"
        local result
        result=$(cel_remote_read "$server" "check user" "$check_script" "USERNAME=$username" 2>/dev/null)
        local status; status=$(grep '^STATUS=' <<< "$result" | cut -d= -f2)
        case "$status" in
            BLOCKED)
                local reason; reason=$(grep '^REASON=' <<< "$result" | cut -d= -f2-)
                echo "  ✗ $server: BLOCKED ($reason)"
                blocked_servers+=("$server|$reason")
                ;;
            NOT_EXIST)
                warn "  ⚠ $server: user tidak ada"
                ;;
            ALLOWED)
                echo "  ✓ $server: ALLOWED"
                allowed_servers+=("$server")
                ;;
        esac
    done
    echo ""

    if [[ ${#blocked_servers[@]} -gt 0 ]]; then
        echo "═══════════════════════════════════════════════════════════"
        error "DIBLOKIR di ${#blocked_servers[@]} server:"
        local b
        for b in "${blocked_servers[@]}"; do
            IFS='|' read -r srv reason <<< "$b"
            error "  • $srv: $reason"
        done
        echo ""
        error "Kebijakan: UID 0, UID<1000, akun SSH aktif → SELALU DIBLOKIR"
        echo ""
        if [[ ${#allowed_servers[@]} -eq 0 ]]; then
            error "Tidak ada server yang bisa diproses."
            return 1
        fi
        read -rp "Lanjut hanya di ${#allowed_servers[@]} server ALLOWED? (y/N): " ans
        [[ ! "$ans" =~ ^[Yy]$ ]] && return 1
    fi

    echo ""
    echo "Pilihan penghapusan:"
    echo "  1. Hapus user SAJA (HOME tetap)"
    echo "  2. Hapus user + HOME (HOME dihapus)"
    echo "  0. Batal"
    read -rp "Pilih (0-2): " choice

    local remove_home="false" confirm_word=""
    case "$choice" in
        1) remove_home="false"; confirm_word="DELETE_USER_${username}" ;;
        2) remove_home="true";  confirm_word="DELETE_USER_AND_HOME_${username}" ;;
        *) return 1 ;;
    esac

    if [[ "$remove_home" == "true" ]]; then
        error "⚠️  HAPUS USER + HOME: $username (HOME dihapus permanen!)"
    fi

    if ! confirm_destructive "Hapus user '$username' di ${#allowed_servers[@]} server?" "$confirm_word"; then
        return 1
    fi

    local del_script
    del_script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if ! id "$USERNAME" &>/dev/null; then echo "OK: not exists"; echo "__RS_RESULT__: OK"; exit 0; fi
uid=$(id -u "$USERNAME")
current_user=$(id -un)
[[ "$uid" -eq 0 ]] && { echo "__RS_ERROR__: UID 0 blocked" >&2; exit 1; }
[[ "$uid" -lt 1000 ]] && { echo "__RS_ERROR__: UID<1000 blocked" >&2; exit 1; }
[[ "$USERNAME" == "$current_user" ]] && { echo "__RS_ERROR__: current SSH user" >&2; exit 1; }

TS=$(date +%Y%m%d%H%M%S)
$SUDO cp -a /etc/passwd "/etc/passwd.bak.$TS" 2>/dev/null || true
$SUDO cp -a /etc/shadow "/etc/shadow.bak.$TS" 2>/dev/null || true
$SUDO cp -a /etc/group "/etc/group.bak.$TS" 2>/dev/null || true

if [[ "$REMOVE_HOME" == "true" ]]; then
    $SUDO userdel -r "$USERNAME"
else
    $SUDO userdel "$USERNAME"
fi
echo "OK: user dihapus (remove_home=$REMOVE_HOME)"
echo "__RS_RESULT__: OK"
REMOTE
)

    local idx ok=0 fail=0
    for idx in "${allowed_servers[@]}"; do
        local server; server="$idx"
        info "Hapus $username di $server ..."
        if cel_remote_exec "$server" "delete user" "$del_script" \
                "USERNAME=$username" "REMOVE_HOME=$remove_home"; then
            ok=$((ok+1))
        else
            fail=$((fail+1))
        fi
    done
    echo ""
    info "Ringkasan: OK=$ok FAIL=$fail"
    audit_log "INFO" "user_delete: user=$username remove_home=$remove_home ok=$ok fail=$fail"
}

user_change_password() {
    read_servers; select_servers || return
    read -rp "Username: " username
    [[ -z "$username" ]] && { error "Kosong."; return 1; }
    read -rsp "New password: " pw1; echo
    read -rsp "Confirm: " pw2; echo
    [[ "$pw1" != "$pw2" ]] && { error "Tidak sama."; return 1; }
    [[ ${#pw1} -lt 8 ]] && { error "Min 8 karakter."; return 1; }

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
id "$USERNAME" &>/dev/null || { echo "__RS_ERROR__: user tidak ada" >&2; exit 1; }
echo "$USERNAME:$NEWPASS" | $SUDO chpasswd
echo "OK: password changed for $USERNAME"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Change password $username" \
        "USERNAME=$username" "NEWPASS=$pw1"
}

user_lock_unlock() {
    read_servers; select_servers || return
    read -rp "Username: " username
    [[ -z "$username" ]] && { error "Kosong."; return 1; }

    echo ""
    echo "Pilih aksi:"
    echo "  1. Lock user"
    echo "  2. Unlock user"
    echo "  3. Lock + Kill semua proses"
    echo "  0. Batal"
    read -rp "Pilih (0-3): " a

    local action=""
    case "$a" in
        1) action="lock" ;;
        2) action="unlock" ;;
        3) action="lock_kill" ;;
        *) return 1 ;;
    esac

    if [[ "$action" == "lock_kill" ]]; then
        local total_proc=0
        local idx
        for idx in "${SELECTED_INDICES[@]}"; do
            local server; server=$(get_server_by_index "$idx")
            local cnt
            cnt=$(cel_remote_read "$server" "count proc" \
                "ps -u '$username' -o pid= 2>/dev/null | wc -l; echo __RS_RESULT__: OK" 2>/dev/null | grep -v '__RS_RESULT__' | tr -d '[:space:]')
            [[ "$cnt" =~ ^[0-9]+$ ]] && total_proc=$((total_proc + cnt))
        done
        if (( total_proc == 0 )); then
            warn "Tidak ada proses aktif. Lock saja?"
            confirm_action "Lanjutkan Lock saja?" || return 1
            action="lock"
        else
            error "⚠️  $total_proc proses akan dihentikan."
            confirm_destructive "Kill $total_proc proses + lock '$username'?" "KILL_$username" || return 1
        fi
    else
        confirm_action "Lanjutkan $action untuk '$username'?" || return 1
    fi

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
id "$USERNAME" &>/dev/null || { echo "__RS_ERROR__: user tidak ada" >&2; exit 1; }
uid=$(id -u "$USERNAME")
[[ "$uid" -eq 0 ]] && { echo "__RS_ERROR__: UID 0" >&2; exit 1; }
[[ "$USERNAME" == "$(id -un)" ]] && { echo "__RS_ERROR__: current SSH user" >&2; exit 1; }

TS=$(date +%Y%m%d%H%M%S)
$SUDO cp -a /etc/shadow "/etc/shadow.rsbak.$TS" 2>/dev/null || true

case "$ACTION" in
    lock)
        $SUDO usermod -L "$USERNAME" || { echo "__RS_ERROR__: usermod -L gagal" >&2; exit 1; }
        $SUDO chage -E 0 "$USERNAME" || {
            echo "__RS_ERROR__: chage gagal — rollback" >&2
            $SUDO usermod -U "$USERNAME" 2>/dev/null || true
            exit 1
        }
        echo "OK: user locked"
        ;;
    unlock)
        $SUDO usermod -U "$USERNAME" || { echo "__RS_ERROR__: usermod -U gagal" >&2; exit 1; }
        $SUDO chage -E -1 "$USERNAME" || {
            echo "__RS_ERROR__: chage gagal" >&2
            exit 1
        }
        echo "OK: user unlocked"
        ;;
    lock_kill)
        $SUDO usermod -L "$USERNAME" || exit 1
        $SUDO chage -E 0 "$USERNAME" || exit 1
        COUNT=$(ps -u "$USERNAME" -o pid= 2>/dev/null | wc -l)
        if (( COUNT > 0 )); then
            $SUDO pkill -TERM -u "$USERNAME" 2>/dev/null || true
            sleep 2
            REMAIN=$(ps -u "$USERNAME" -o pid= 2>/dev/null | wc -l)
            if (( REMAIN > 0 )); then
                $SUDO pkill -KILL -u "$USERNAME" 2>/dev/null || true
            fi
            echo "OK: killed processes + locked"
        else
            echo "OK: no processes + locked"
        fi
        ;;
esac
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "User $action $username" \
        "USERNAME=$username" "ACTION=$action"
}

# ══════════════════════════════════════════════════════════════
# GROUP MANAGEMENT
# ══════════════════════════════════════════════════════════════

group_list() {
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
echo "════════════════════════════════════════"
echo "  GROUP LIST"
echo "════════════════════════════════════════"
printf "%-25s %-8s %s\n" "group" "gid" "members"
getent group 2>/dev/null | awk -F: '{printf "%-25s %-8s %s\n", $1, $3, $4}'
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_readonly "$script" "Group list"
}

group_add() {
    read_servers; select_servers || return
    echo ""
    read -rp "Nama group baru: " groupname
    [[ -z "$groupname" ]] && { error "Kosong."; return 1; }
    if [[ ! "$groupname" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]]; then
        error "Nama group tidak valid: '$groupname'"; return 1
    fi

    if ! confirm_action "Tambah group '$groupname' di ${#SELECTED_INDICES[@]} server?"; then return 1; fi

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
[[ "$GROUPNAME" =~ ^[a-z_][a-z0-9_-]{0,31}$ ]] || { echo "__RS_ERROR__: group name invalid" >&2; exit 1; }

if getent group "$GROUPNAME" &>/dev/null; then
    echo "__RS_ERROR__: group sudah ada" >&2
    exit 1
fi

$SUDO groupadd "$GROUPNAME"
echo "OK: group $GROUPNAME dibuat"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Add group $groupname" \
        "GROUPNAME=$groupname"
}

group_del() {
    read_servers; select_servers || return
    echo ""
    read -rp "Nama group yang akan dihapus: " groupname
    [[ -z "$groupname" ]] && { error "Kosong."; return 1; }
    
    if ! confirm_destructive "Hapus group '$groupname'?" "DELETE_GROUP_$groupname"; then return 1; fi

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
if ! getent group "$GROUPNAME" &>/dev/null; then
    echo "OK: group tidak ada"
    echo "__RS_RESULT__: OK"
    exit 0
fi
$SUDO groupdel "$GROUPNAME"
echo "OK: group $GROUPNAME dihapus"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Delete group $groupname" \
        "GROUPNAME=$groupname"
}

group_add_user() {
    read_servers; select_servers || return
    echo ""
    read -rp "Nama user: " username
    [[ -z "$username" ]] && { error "Kosong."; return 1; }
    read -rp "Nama group: " groupname
    [[ -z "$groupname" ]] && { error "Kosong."; return 1; }

    if ! confirm_action "Tambahkan user '$username' ke group '$groupname' di ${#SELECTED_INDICES[@]} server?"; then return 1; fi

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
id "$USERNAME" &>/dev/null || { echo "__RS_ERROR__: user tidak ada" >&2; exit 1; }
getent group "$GROUPNAME" &>/dev/null || { echo "__RS_ERROR__: group tidak ada" >&2; exit 1; }

$SUDO usermod -aG "$GROUPNAME" "$USERNAME"
echo "OK: $USERNAME ditambahkan ke group $GROUPNAME"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Add $username to $groupname" \
        "USERNAME=$username" "GROUPNAME=$groupname"
}

group_remove_user() {
    read_servers; select_servers || return
    echo ""
    read -rp "Nama user: " username
    [[ -z "$username" ]] && { error "Kosong."; return 1; }
    read -rp "Nama group: " groupname
    [[ -z "$groupname" ]] && { error "Kosong."; return 1; }

    if ! confirm_action "Keluarkan user '$username' dari group '$groupname' di ${#SELECTED_INDICES[@]} server?"; then return 1; fi

    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
set -uo pipefail
id "$USERNAME" &>/dev/null || { echo "__RS_ERROR__: user tidak ada" >&2; exit 1; }
getent group "$GROUPNAME" &>/dev/null || { echo "__RS_ERROR__: group tidak ada" >&2; exit 1; }

$SUDO gpasswd -d "$USERNAME" "$GROUPNAME"
echo "OK: $USERNAME dikeluarkan dari group $GROUPNAME"
echo "__RS_RESULT__: OK"
REMOTE
)
    run_action_on_servers_privileged "$script" "Remove $username from $groupname" \
        "USERNAME=$username" "GROUPNAME=$groupname"
}

# ══════════════════════════════════════════════════════════════
# MAIN MENU: USER & GROUP MANAGEMENT
# ══════════════════════════════════════════════════════════════

user_management_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  USER & GROUP MANAGEMENT"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Users ---"
        echo "1. User List"
        echo "2. Add user"
        echo "3. Delete user"
        echo "4. Change password"
        echo "5. Lock/Unlock user"
        echo ""
        echo "--- Groups ---"
        echo "6. Group List"
        echo "7. Add group"
        echo "8. Delete group"
        echo "9. Add user to group"
        echo "10. Remove user from group"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-10): "
        read -r c
        case "$c" in
            1) user_list ;;
            2) user_add ;;
            3) user_delete_protected ;;
            4) user_change_password ;;
            5) user_lock_unlock ;;
            6) group_list ;;
            7) group_add ;;
            8) group_del ;;
            9) group_add_user ;;
            10) group_remove_user ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
