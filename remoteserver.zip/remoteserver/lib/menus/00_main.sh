#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
main_menu() {
    while true; do
        echo ""
        echo -e "${CYAN}${BOLD}  REMOTE SERVER MANAGEMENT V2${NC}"
        echo ""
        echo -e "${YELLOW}--- SSH & Otentikasi ---${NC}"
        echo "1. SSH Key Management"
        echo "2. SSH & Server List Management"
        echo ""
        echo -e "${YELLOW}--- Server Operation ---${NC}"
        echo "3. Server Maintainer"
        echo "4. Server Information"
        echo "5. User & Group Management"
        echo "6. Security Management"
        echo "7. Service Server Management"
        echo ""
        echo -e "${YELLOW}--- Network & Tools ---${NC}"
        echo "8. Basic Tools"
        echo ""
        echo -e "${YELLOW}--- Advanced ---${NC}"
        echo "9.  Server Tune-Up"
        echo "10. Instalasi Server Management"
        echo "11. Proxmox Cluster Check"
        echo ""
        echo "0. Exit"
        echo ""
        echo -n "Pilih (0-11): "
        read -r choice

        case "$choice" in
            1)  ssh_key_management_menu ;;
            2)  ssh_management_menu ;;
            3)  server_maintainer_menu ;;
            4)  server_information_menu ;;
            5)  user_management_menu ;;
            6)  security_management_menu ;;
            7)  service_management_menu ;;
            8)  basic_tools_menu ;;
            9)  server_tune_up_menu ;;
            10) instalasi_server_menu ;;
            11) proxmox_menu ;;
            0)  info "Bye!"; exit 0 ;;
            *)  warn "Invalid" ;;
        esac
    done
}
