#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

show_server_info() {
    local server="$1"
    info "System Information for $server"
    echo "────────────────────────────────────────"
    local script
    script=$(cat <<'REMOTE'
#!/bin/bash
echo "════════════════════════════════════════"
echo "  SYSTEM INFO"
echo "════════════════════════════════════════"
echo "Hostname : $(hostname 2>/dev/null)"
echo "Uptime   : $(uptime -p 2>/dev/null || uptime)"
echo "OS       : $(. /etc/os-release 2>/dev/null && echo "$PRETTY_NAME" || cat /etc/redhat-release 2>/dev/null || uname -s)"
echo "Kernel   : $(uname -r)"
echo "Arch     : $(uname -m)"
echo ""
echo "── CPU ──"
nproc 2>/dev/null | xargs echo "Cores:"
echo ""
echo "── Memory ──"
free -h 2>/dev/null | grep -E '^Mem:|^Swap:'
echo ""
echo "── Disk ──"
df -h 2>/dev/null | grep -E '^(Filesystem|/dev/)'
echo ""
echo "── Load ──"
cat /proc/loadavg 2>/dev/null | awk '{print "1min:", $1, "5min:", $2, "15min:", $3}'
echo ""
echo "── Top 5 CPU ──"
ps aux --sort=-%cpu 2>/dev/null | head -6 | tail -5 | awk '{printf "  CPU:%5s%% MEM:%5s%% %s\n", $3, $4, $11}'
echo ""
echo "── Services ──"
for svc in nginx apache2 httpd mysql mariadb postgresql redis ssh docker; do
    systemctl is-active --quiet "$svc" 2>/dev/null && echo "  ✓ $svc: active"
done
echo "__RS_RESULT__: OK"
REMOTE
)
    cel_remote_read "$server" "system info" "$script"
}

info_server() {
    read_servers; select_servers || return
    local idx n=0 total=${#SELECTED_INDICES[@]}
    for idx in "${SELECTED_INDICES[@]}"; do
        n=$((n+1))
        local server; server=$(get_server_by_index "$idx")
        show_progress "$n" "$total" "$server"
        echo ""
        show_server_info "$server"
        echo ""
    done
}

info_disk_structure() {
    local script='lsblk -f 2>/dev/null || echo "lsblk not available"; echo "__RS_RESULT__: OK"'
    run_action_on_servers_readonly "$script" "Disk structure (lsblk)"
}

info_partition_disk() {
    local script='if [ "$(id -u)" -eq 0 ]; then fdisk -l 2>/dev/null; else sudo -n fdisk -l 2>/dev/null || echo "fdisk butuh root"; fi; echo "__RS_RESULT__: OK"'
    run_action_on_servers_readonly "$script" "Partition (fdisk)"
}

info_uuid_fstype() {
    local script='if [ "$(id -u)" -eq 0 ]; then blkid 2>/dev/null; else sudo -n blkid 2>/dev/null || echo "blkid butuh root"; fi; echo "__RS_RESULT__: OK"'
    run_action_on_servers_readonly "$script" "UUID/filesystem (blkid)"
}

server_information_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  SERVER INFORMATION"
        echo "═══════════════════════════════════════════════════════════"
        echo "1. Info Server (full system monitor)"
        echo "2. Check disk structure (lsblk)"
        echo "3. Check partition disk (fdisk)"
        echo "4. Check UUID & filesystem (blkid)"
        echo "5. Health Check Dashboard"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-5): "
        read -r c
        case "$c" in
            1) info_server ;;
            2) info_disk_structure ;;
            3) info_partition_disk ;;
            4) info_uuid_fstype ;;
            5) health_check_dashboard ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
