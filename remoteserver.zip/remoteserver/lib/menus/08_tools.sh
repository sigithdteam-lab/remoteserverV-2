#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

net_ping_subnet() {
    echo ""
    echo "Format yang didukung:"
    echo "  • CIDR        : 192.168.1.0/24"
    echo "  • IP Tunggal  : 192.168.1.10"
    echo "  • Range       : 192.168.1.10-100 (atau 192.168.1.10-192.168.1.100)"
    read -rp "Masukkan target: " target
    [[ -z "$target" ]] && return 1

    command -v nmap >/dev/null 2>&1 || { warn "nmap tidak ada (apt install nmap)"; return 1; }

    local nmap_target=""

    if [[ "$target" == *"-"* ]]; then
        local start="${target%-*}"
        local end="${target#*-}"
        if [[ "$end" != *"."* ]]; then
            local prefix="${start%.*}"
            nmap_target="${prefix}.${end#*.}" 
            nmap_target="${prefix}.${start##*.}-${prefix}.${end}" 
        else
            nmap_target="${start}-${end}"
        fi
    else
        nmap_target="$target"
    fi

    info "Menjalankan nmap -sn $nmap_target ..."
    sudo nmap -sn "$nmap_target" 2>/dev/null | grep -E "Nmap scan|Host is up" || nmap -sn "$nmap_target" 2>/dev/null | grep -E "Nmap scan|Host is up"
}

net_traceroute() { read -rp "Dest: " d; [[ -z "$d" ]] && return 1; traceroute "$d"; }
net_dig()        { read -rp "Domain: " d; [[ -z "$d" ]] && return 1; dig "$d" any; }
net_nslookup()   { read -rp "Target: " t; [[ -z "$t" ]] && return 1; nslookup "$t"; }
net_whois()      { read -rp "IP/domain: " t; [[ -z "$t" ]] && return 1; whois "$t"; }
apnic_prefix_whois() { read -rp "Prefix IPv4/IPv6: " p; [[ -z "$p" ]] && return 1; whois -h whois.apnic.net "$p" 2>/dev/null || whois "$p"; }
apnic_asn_info()     { read -rp "AS number: " a; [[ -z "$a" ]] && return 1; whois -h whois.apnic.net "AS$a" 2>/dev/null || whois "AS$a"; }

mail_check_mx() {
    read -rp "Domain: " d; [[ -z "$d" ]] && return 1
    read_servers; select_servers || return
    local script="dig $d MX +short 2>/dev/null || echo 'dig not available'; echo '__RS_RESULT__: OK'"
    run_action_on_servers_readonly "$script" "MX $d"
}
mail_check_ptr() {
    read -rp "IP: " ip; validate_ip "$ip" || return 1
    read_servers; select_servers || return
    local script="dig -x $ip +short 2>/dev/null || echo 'dig not available'; echo '__RS_RESULT__: OK'"
    run_action_on_servers_readonly "$script" "PTR $ip"
}
mail_spf() {
    read -rp "Domain: " d; [[ -z "$d" ]] && return 1
    read_servers; select_servers || return
    local script="dig $d TXT +short 2>/dev/null | grep -i 'v=spf1' || echo 'No SPF record'; echo '__RS_RESULT__: OK'"
    run_action_on_servers_readonly "$script" "SPF $d"
}
mail_dmarc() {
    read -rp "Domain: " d; [[ -z "$d" ]] && return 1
    read_servers; select_servers || return
    local script="dig _dmarc.$d TXT +short 2>/dev/null | grep -i 'v=DMARC1' || echo 'No DMARC record'; echo '__RS_RESULT__: OK'"
    run_action_on_servers_readonly "$script" "DMARC $d"
}

basic_tools_menu() {
    while true; do
        echo ""
        echo "═══════════════════════════════════════════════════════════"
        echo "  BASIC TOOLS"
        echo "═══════════════════════════════════════════════════════════"
        echo "--- Network Tools (LOCAL) ---"
        echo "1. Ping subnet / IP / Range"
        echo "2. Traceroute"
        echo "3. dig"
        echo "4. nslookup"
        echo "5. whois"
        echo ""
        echo "--- APNIC Tools (LOCAL) ---"
        echo "6. Prefix Whois"
        echo "7. ASN Info"
        echo ""
        echo "--- Mailserver Tools (REMOTE) ---"
        echo "8. Check MX"
        echo "9. Check PTR"
        echo "10. Check SPF"
        echo "11. Check DMARC"
        echo ""
        echo "0. Back"
        echo "═══════════════════════════════════════════════════════════"
        echo -n "Pilih (0-11): "
        read -r c
        case "$c" in
            1) net_ping_subnet ;;
            2) net_traceroute ;;
            3) net_dig ;;
            4) net_nslookup ;;
            5) net_whois ;;
            6) apnic_prefix_whois ;;
            7) apnic_asn_info ;;
            8) mail_check_mx ;;
            9) mail_check_ptr ;;
            10) mail_spf ;;
            11) mail_dmarc ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
