#!/bin/bash
set -uo pipefail

if ! command -v jq >/dev/null 2>&1; then
    echo "[*] Menginstal jq ..."
    if command -v apt-get >/dev/null 2>&1; then
        $SUDO apt-get update -qq && $SUDO apt-get install -y jq -qq
    elif command -v yum >/dev/null 2>&1; then
        $SUDO yum install -y jq -q
    fi
fi
command -v jq >/dev/null 2>&1 || { echo "__RS_ERROR__: jq gagal diinstal" >&2; exit 1; }

if ! command -v clamscan >/dev/null 2>&1; then
    echo "[*] Menginstal ClamAV ..."
    if command -v apt-get >/dev/null 2>&1; then
        $SUDO apt-get update -qq && $SUDO apt-get install -y clamav -qq
    elif command -v yum >/dev/null 2>&1; then
        $SUDO yum install -y epel-release -q && $SUDO yum install -y clamav -q
    fi
    command -v freshclam >/dev/null 2>&1 && $SUDO freshclam -q 2>/dev/null || true
fi
command -v clamscan >/dev/null 2>&1 || { echo "__RS_ERROR__: clamav gagal diinstal" >&2; exit 1; }

mapfile -t FOLDERS < <(echo "$FOLDERS_JSON" | jq -r '.[]')

CLAM_ARGS=(-r --bell -i)
[[ -n "${MODE_FLAG:-}" ]] && CLAM_ARGS+=("$MODE_FLAG")

TOTAL=0
for folder in "${FOLDERS[@]}"; do
    echo ""
    echo "═══ Scanning: $folder ═══"
    $SUDO clamscan "${CLAM_ARGS[@]}" "$folder" 2>&1
    rc=$?
    [[ $rc -eq 1 ]] && TOTAL=$((TOTAL+1))
done
echo ""
echo "Folders with infected: $TOTAL"
echo "__RS_RESULT__: OK"
