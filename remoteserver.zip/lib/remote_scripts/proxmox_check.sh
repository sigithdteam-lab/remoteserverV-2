#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================
set -u

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BOLD='\033[1m'
PURPLE='\033[0;35m'
NC='\033[0m'

section() { echo -e "\n${CYAN}${BOLD}[ $1 ]${NC}"; }
subsection() { echo -e "\n${YELLOW}-- $1 --${NC}"; }
warn() { echo -e "${RED}[WARN] $1${NC}"; }
ok()   { echo -e "${GREEN}[OK] $1${NC}"; }
recommend() { echo -e "   ${PURPLE}[REKOMENDASI]${NC} $1"; }

# ── VARIABEL SUMMARY ──
SUM_VM_RUNNING=0; SUM_VM_TOTAL=0; SUM_HA_ERROR=0; SUM_SVC_DOWN=0; SUM_DISK_WARN=0
SUM_FS_WARN=0; SUM_IO_WARN=0; SUM_QUORUM_OK=0; SUM_ZFS_ISSUE=0; SUM_CEPH_ISSUE=0
SUM_DMESG_ERR=0; SUM_SMART_MISSING=0; SUM_REPL_ERR=0; SUM_BACKUP_MISSING=0
SUM_TASK_FAIL=0; SUM_NET_DOWN=0; SUM_LATENCY_WARN=0; SUM_UPDATES_SEC=0
SUM_REBOOT_NEEDED=0; SUM_VM_LOCKED=0; SUM_SNAP_OLD=0; SUM_VM_PAUSED=0

SUMMARY_DETAILS=()
RECOMMENDATIONS=()
add_detail() { SUMMARY_DETAILS+=("$1"); }
add_recommendation() { RECOMMENDATIONS+=("$1"); }

echo -e "${CYAN}${BOLD}PROXMOX MAINTENANCE CHECK${NC}"
echo ""

# ============================================
# TAHAP 1: KONEKTIVITAS & STATUS DASAR
# ============================================
section "1. NODE STATUS"
printf "%-15s | %-10s | %-10s\n" "Node" "Status" "Uptime"
printf "%-15s | %-10s | %-10s\n" "---------------" "----------" "----------"
for NODE in $(pvesh get /nodes --output-format json 2>/dev/null | grep -oP '"node":"\K[^"]+'); do
    STATUS=$(pvesh get /nodes/$NODE/status --output-format json 2>/dev/null | grep -oP '"status":"\K[^"]+')
    UPTIME=$(pvesh get /nodes/$NODE/status --output-format json 2>/dev/null | grep -oP '"uptime":\K[0-9]+')
    UPTIME_D=$(( ${UPTIME:-0} / 86400 ))
    printf "%-15s | %-10s | %-10s\n" "$NODE" "${STATUS:-unknown}" "${UPTIME_D} Hari"
done

section "2. NETWORK STATUS"
printf "%-15s | %-25s\n" "Interface" "Traffic (RX / TX)"
printf "%-15s | %-25s\n" "---------------" "-------------------------"
for IFACE in $(ip -o link show up | awk -F': ' '{print $2}' | grep -v lo | grep -E 'eth|vmbr|bond'); do
    STAT=$(ip -s link show "$IFACE" 2>/dev/null | awk 'NR==4{rx=$2} NR==6{tx=$2} END{print rx" / "tx}')
    printf "%-15s | %-25s\n" "$IFACE" "$STAT"
done
BOND_ISSUE=$(ip -o link show | awk -F': ' '$2 ~ /bond|vmbr/ && $0 !~ /state UP/ {print $2}' | grep -v lo)
if [[ -n "$BOND_ISSUE" ]]; then
    warn "Bond/Bridge down: $BOND_ISSUE"; SUM_NET_DOWN=$(echo "$BOND_ISSUE" | wc -l); add_detail "Net down: $BOND_ISSUE"
    add_recommendation "Periksa kabel fisik / switch pada interface $BOND_ISSUE."
else
    ok "Bond/Bridge UP"
fi

section "3. CLUSTER LATENCY"
printf "%-15s | %-10s\n" "Node" "Latency"
printf "%-15s | %-10s\n" "---------------" "----------"
for NODE in $(pvecm nodes 2>/dev/null | awk 'NR>1 && $3!="offline"{print $3}'); do
    if [[ "$NODE" != "$(hostname)" ]]; then
        PING=$(ping -c 3 -W 1 "$NODE" 2>/dev/null | tail -1 | awk -F'/' '{print $5}')
        if [[ -n "$PING" ]]; then
            printf "%-15s | %-10s\n" "$NODE" "${PING} ms"
            if awk "BEGIN{exit !($PING > 5)}"; then
                warn "Latency $NODE tinggi"; SUM_LATENCY_WARN=$((SUM_LATENCY_WARN+1)); add_detail "Latency $NODE: ${PING}ms"
                add_recommendation "Cek jaringan cluster (Switch/Corosync) karena latensi ke $NODE > 5ms."
            fi
        else
            printf "%-15s | %-10s\n" "$NODE" "UNREACHABLE"
            warn "$NODE unreachable"; SUM_LATENCY_WARN=$((SUM_LATENCY_WARN+1)); add_detail "$NODE unreachable"
            add_recommendation "Node $NODE tidak merespons. Cek status server atau jaringan."
        fi
    fi
done

# ============================================
# TAHAP 2: KESEHATAN CLUSTER
# ============================================
section "4. CLUSTER NODES"
pvecm nodes 2>/dev/null || echo "Bukan cluster Proxmox"

section "5. COROSYNC STATUS"
CORO=$(corosync-quorumtool -s 2>&1)
echo "$CORO" | grep -E "Quorate|Nodes|Ring ID"
pvecm status 2>&1 | grep -E "Nodes|Expected votes|Total votes|Quorum|Flags"
if echo "$CORO" | grep -qi "Quorate:.*Yes"; then
    ok "Quorum: OK"; SUM_QUORUM_OK=1
else
    warn "Quorum: TIDAK OK"; add_detail "Quorum bermasalah"
    add_recommendation "Quorum Hilang! Jangan restart node secara bersamaan. Cek 'pvecm expected [jumlah_node]'."
fi

section "6. PROXMOX SERVICES"
for SVC in pve-cluster pvedaemon pveproxy pvestatd corosync; do
    STATUS=$(systemctl is-active "$SVC" 2>/dev/null)
    if [[ "$STATUS" == "active" ]]; then
        ok "$SVC: $STATUS"
    else
        warn "$SVC: $STATUS"; SUM_SVC_DOWN=$((SUM_SVC_DOWN+1)); add_detail "SVC $SVC: $STATUS"
        add_recommendation "Service $SVC mati. Jalankan: systemctl restart $SVC."
    fi
done

section "7. HA MANAGER STATUS"
HA_STATUS=$(ha-manager status 2>&1)
echo "$HA_STATUS"
SUM_HA_ERROR=$(echo "$HA_STATUS" | grep -ci "error\|fenced\|stopped" || true)
[[ "$SUM_HA_ERROR" -gt 0 ]] && add_detail "HA: $SUM_HA_ERROR resource bermasalah" && \
add_recommendation "Cek log HA (ha-manager status & journalctl -u pve-ha-lrm)."

# ============================================
# TAHAP 3: STORAGE & HARDWARE
# ============================================
section "8. STORAGE STATUS (MB)"
printf "%-15s | %-8s | %-8s | %-12s | %-12s | %-12s | %-6s\n" "Name" "Type" "Status" "Total(MB)" "Used(MB)" "Avail(MB)" "Used%"
printf "%-15s | %-8s | %-8s | %-12s | %-12s | %-12s | %-6s\n" "---------------" "--------" "--------" "------------" "------------" "------------" "------"
pvesm status 2>/dev/null | awk 'NR>1 {printf "%-15s | %-8s | %-8s | %-12.2f | %-12.2f | %-12.2f | %-6s\n", $1, $2, $3, $4/1024, $5/1024, $6/1024, $7}'

section "9. DISK INFO (lsblk)"
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT,MODEL 2>/dev/null

section "10. SMART HEALTH CHECK"
if ! command -v smartctl >/dev/null 2>&1; then
    warn "smartctl tidak terinstall"; SUM_SMART_MISSING=1; add_detail "smartctl tidak ada"
    add_recommendation "Install smartmontools: apt install smartmontools."
else
    for DISK in $(lsblk -dn -o NAME | grep -E '^(sd|nvme|vd)'); do
        DEV="/dev/${DISK}"
        echo ">>> $DEV"
        if [[ "$DISK" == nvme* ]]; then
            SMART_OUT=$(smartctl -H -A "$DEV" 2>/dev/null)
            echo "$SMART_OUT" | grep -E "SMART overall-health|Percentage used|Temperature|Available Spare"
        else
            SMART_OUT=$(smartctl -H "$DEV" 2>/dev/null)
            echo "$SMART_OUT" | grep -E "SMART overall-health|SMART Health Status"
        fi
        if echo "$SMART_OUT" | grep -qi "PASSED"; then
            ok "$DEV health: PASSED"
        else
            warn "$DEV health: FAILED/UNKNOWN"; SUM_DISK_WARN=$((SUM_DISK_WARN+1)); add_detail "SMART $DEV: FAILED"
            add_recommendation "Disk $DEV bermasalah! Segera backup data dan ganti disk."
        fi
        if [[ "$DISK" != nvme* ]]; then
            BAD_SECTORS=$(smartctl -A "$DEV" 2>/dev/null | awk '$1==5 || $1==197 || $1==198 {sum+=$10} END{print sum+0}')
            if [[ "$BAD_SECTORS" -gt 0 ]]; then
                warn "$DEV bad sectors: $BAD_SECTORS"; SUM_DISK_WARN=$((SUM_DISK_WARN+1)); add_detail "SMART $DEV: $BAD_SECTORS bad sectors"
                add_recommendation "Disk $DEV memiliki bad sector. Segera lakukan penggantian."
            fi
        fi
    done
fi

section "11. ZFS HEALTH"
if command -v zpool >/dev/null 2>&1 && [[ -n "$(zpool list -H -o name 2>/dev/null)" ]]; then
    printf "%-15s | %-10s | %-10s | %-10s\n" "Name" "Size" "Alloc" "Free"
    printf "%-15s | %-10s | %-10s | %-10s\n" "---------------" "----------" "----------" "----------"
    zpool list -H -o name,size,alloc,free | awk '{printf "%-15s | %-10s | %-10s | %-10s\n", $1, $2, $3, $4}'
    DEGRADED=$(zpool list -H -o name,health 2>/dev/null | awk '$2!="ONLINE"{print $1}')
    if [[ -n "$DEGRADED" ]]; then
        warn "ZFS pool tidak ONLINE: $DEGRADED"; SUM_ZFS_ISSUE=1; add_detail "ZFS DEGRADED: $DEGRADED"
        add_recommendation "Jalankan 'zpool status -v' dan ganti disk yang rusak pada pool $DEGRADED."
    else
        ok "Semua ZFS pool ONLINE"
    fi
else
    echo "ZFS tidak terpasang / tidak ada pool"
fi

section "12. CEPH HEALTH"
if command -v ceph >/dev/null 2>&1 && ceph -s >/dev/null 2>&1; then
    CEPH_S=$(ceph -s 2>&1)
    echo "$CEPH_S" | grep -E "cluster:|health:|mon:|mgr:|osd:"
    if echo "$CEPH_S" | grep -q "HEALTH_OK"; then
        ok "Ceph HEALTH_OK"
    else
        warn "Ceph tidak HEALTH_OK"; SUM_CEPH_ISSUE=1; add_detail "Ceph: $(echo "$CEPH_S" | grep -o 'HEALTH_[A-Z]*' | head -1)"
        add_recommendation "Jalankan 'ceph health detail' dan 'ceph osd tree' untuk cek OSD yang down."
    fi
else
    echo "Ceph tidak terpasang / tidak aktif"
fi

section "13. FILESYSTEM USAGE"
df -hT | grep -Ev "tmpfs|devtmpfs"
HIGH=$(df -hP | awk 'NR>1 && $5+0 > 85' | wc -l)
SUM_FS_WARN=$HIGH
if [[ "$HIGH" -gt 0 ]]; then
    warn "Ada $HIGH partisi > 85%"; add_detail "FS: $HIGH partisi > 85%"
    add_recommendation "Bersihkan log lama atau hapus file ISO/Template yang tidak terpakai."
else
    ok "Semua partisi < 85%"
fi

# ============================================
# TAHAP 4: RESOURCE
# ============================================
section "14. NODE MEMORY"
printf "%-12s | %-12s | %-12s | %-12s\n" "Total" "Used" "Free" "Available"
printf "%-12s | %-12s | %-12s | %-12s\n" "------------" "------------" "------------" "------------"
free -m | awk 'NR==2 {printf "%-10s MB | %-10s MB | %-10s MB | %-10s MB\n", $2, $3, $4, $7}'

section "15. CPU, LOAD & IO STATUS"
UPTIME_INFO=$(uptime -p 2>/dev/null || uptime | awk -F'up' '{print "up"$2}' | cut -d, -f1-2)
LOAD_AVG=$(cat /proc/loadavg | awk '{print $1", "$2", "$3}')
NODENAME=$(hostname)
IO_WAIT=$(pvesh get /nodes/${NODENAME}/status 2>/dev/null | grep -i wait | awk '{print $3}' | tr -d ',')
IO_WAIT=${IO_WAIT:-0}
echo "Uptime       : $UPTIME_INFO"
echo "Load Average : $LOAD_AVG"
echo "IO Wait (WA) : ${IO_WAIT} %"
if awk "BEGIN{exit !($IO_WAIT > 20)}"; then
    warn "IO Wait tinggi (>20%)"; SUM_IO_WARN=1; add_detail "IO Wait tinggi: ${IO_WAIT}%"
    add_recommendation "I/O Storage lambat. Cek SMART disk atau migrasi VM berat ke node lain."
else
    ok "IO Wait normal"
fi

# ============================================
# TAHAP 5: VIRTUAL MACHINE
# ============================================
section "16. LOCAL VM SUMMARY & STATUS KHUSUS"
qm list 2>/dev/null
PAUSED_VMS=$(qm list 2>/dev/null | awk 'NR>1 && ($3=="paused" || $3=="suspended"){print $1" ("$2") - Status: "$3}')
if [[ -n "$PAUSED_VMS" ]]; then
    warn "Ditemukan VM berstatus PAUSED/SUSPENDED:"
    echo "$PAUSED_VMS" | sed 's/^/   /'
    SUM_VM_PAUSED=$(echo "$PAUSED_VMS" | wc -l)
    add_detail "$SUM_VM_PAUSED VM berstatus Paused/Suspended"
    add_recommendation "Gunakan 'qm resume <vmid>' untuk VM paused, atau 'qm start <vmid>' jika suspend. Cek juga storage."
else
    ok "Tidak ada VM Paused/Suspended"
fi

section "17. VM RESOURCES (Disk I/O)"
printf "%-15s | %-6s | %-15s | %-15s\n" "ID" "Type" "Disk Read (MB)" "Disk Write (MB)"
printf "%-15s | %-6s | %-15s | %-15s\n" "---------------" "------" "---------------" "---------------"
pvesh get /cluster/resources --type vm --output-format json 2>/dev/null | \
grep -oP '"id":"\K[^"]+|"diskread":\K[0-9]+|"diskwrite":\K[0-9]+' | \
awk '
    /^qemu/ { id=$0; next }
    /^[0-9]+$/ { 
        if (read == "") { read=$0 } 
        else { 
            printf "%-15s | %-6s | %-15.2f | %-15.2f\n", id, "qemu", read/1024/1024, $0/1024/1024; 
            id=""; read=""; 
        } 
    }
'

section "18. VM LOCK STATUS"
LOCKED_FOUND=0
for VMID in $(qm list | awk 'NR>1{print $1}'); do
    LOCK=$(qm config "$VMID" 2>/dev/null | grep -i "^lock:")
    if [[ -n "$LOCK" ]]; then
        echo "   VM $VMID : $LOCK"; LOCKED_FOUND=1; SUM_VM_LOCKED=$((SUM_VM_LOCKED+1)); add_detail "VM $VMID locked"
        add_recommendation "VM $VMID terkunci ($LOCK). Jika tidak ada task berjalan, hapus lock: 'qm unlock $VMID'."
    fi
done
[[ "$LOCKED_FOUND" -eq 0 ]] && ok "Tidak ada VM terkunci"

section "19. VM REPLICATION STATUS"
if pvesh get /cluster/replication >/dev/null 2>&1; then
    REPL_JSON=$(pvesh get /cluster/replication --output-format json 2>/dev/null)
    if [[ "$REPL_JSON" == "[]" || -z "$REPL_JSON" ]]; then
        echo "Tidak ada konfigurasi replikasi"
    else
        echo "$REPL_JSON" | grep -oP '"id":"\K[^"]+|"fail_count":\K[0-9]+' | paste - - | awk '{printf "%-20s | Fail Count: %s\n", $1, $2}'
        REPL_ERR=$(echo "$REPL_JSON" | grep -o '"fail_count":[0-9]*' | awk -F: '{s+=$2} END{print s+0}')
        SUM_REPL_ERR=$REPL_ERR
        [[ "$REPL_ERR" -gt 0 ]] && add_detail "Replikasi gagal: $REPL_ERR" && \
        add_recommendation "Replikasi gagal. Cek konektivitas antar-node dan space storage target." || ok "Replikasi OK"
    fi
fi

# ============================================
# TAHAP 6: LOG & MAINTENANCE
# ============================================
section "20. RECENT TASKS (10 Terakhir)"
TASKS_JSON=$(pvesh get /nodes/$(hostname)/tasks --limit 10 --output-format json 2>/dev/null)
if [[ -n "$TASKS_JSON" ]]; then
    printf "%-18s | %-8s | %-15s | %-10s\n" "Waktu" "VMID" "Tipe Task" "Status"
    printf "%-18s | %-8s | %-15s | %-10s\n" "------------------" "--------" "---------------" "----------"
    
    if command -v jq >/dev/null 2>&1; then
        echo "$TASKS_JSON" | jq -r '.[] | "\(.starttime | strftime("%Y-%m-%d %H:%M")) | \(.id // "-") | \(.type) | \(.status)"' | \
        awk -F' \\| ' '{printf "%-18s | %-8s | %-15s | %-10s\n", $1, $2, $3, $4}'
    else
        echo "$TASKS_JSON" | grep -oP '"starttime":\K[0-9]+|"id":"\K[^"]+|"type":"\K[^"]+|"status":"\K[^"]+' | \
        awk '
            /^[0-9]+$/ { time=$0; next }
            /^[a-zA-Z0-9]+$/ && !id { id=$0; next }
            /^[a-zA-Z]/ && !type { type=$0; next }
            /^[A-Z]/ { 
                cmd="date -d @"time" +\"%Y-%m-%d %H:%M\""; cmd | getline formatted_time; close(cmd);
                printf "%-18s | %-8s | %-15s | %-10s\n", formatted_time, id, type, $0; 
                time=""; id=""; type=""; status="";
            }
        '
    fi
    FAILED_TASKS=$(echo "$TASKS_JSON" | grep -o '"status":"[^"]*"' | grep -v '"status":"OK"' | grep -v '"status":"RUNNING"' | wc -l)
    SUM_TASK_FAIL=$FAILED_TASKS
    [[ "$FAILED_TASKS" -gt 0 ]] && add_detail "Task gagal: $FAILED_TASKS" && \
    add_recommendation "Cek detail task gagal via Web UI (Tasks) atau log journal." || ok "Tidak ada task gagal"
fi

section "21. DMESG ERRORS"
DMESG_ERR=$(dmesg --level=err,warn 2>/dev/null | tail -n 5)
if [[ -n "$DMESG_ERR" ]]; then
    echo "$DMESG_ERR" | sed 's/^/   /'
    SUM_DMESG_ERR=$(echo "$DMESG_ERR" | wc -l); add_detail "dmesg: $SUM_DMESG_ERR err (5 terakhir)"
    add_recommendation "Ada pesan error di kernel (dmesg). Cek hardware atau driver."
else
    ok "Tidak ada error terbaru"
fi

section "22. LAST BACKUP"
if command -v vzdump >/dev/null 2>&1; then
    for VMID in $(qm list | awk 'NR>1{print $1}'); do
        LAST=$(grep -h "vzdump.*$VMID" /var/log/vzdump/*.log 2>/dev/null | tail -1 | awk '{print $1, $2}')
        if [[ -n "$LAST" ]]; then
            echo "   VM $VMID : $LAST"
        else
            echo "   VM $VMID : (no log)"; SUM_BACKUP_MISSING=$((SUM_BACKUP_MISSING+1)); add_detail "VM $VMID: no backup"
            add_recommendation "VM $VMID belum pernah di-backup. Buat jadwal backup via Web UI."
        fi
    done
fi

section "23. OLD SNAPSHOTS (>30d)"
FOUND_SNAP=0; NOW_TS=$(date +%s)
for VMID in $(qm list | awk 'NR>1{print $1}'); do
    SNAPS=$(qm listsnapshot "$VMID" 2>/dev/null | grep -v "current\|You have no")
    if [[ -n "$SNAPS" ]]; then
        while IFS= read -r line; do
            SNAP_NAME=$(echo "$line" | awk '{print $1}')
            SNAP_DATE=$(echo "$line" | awk '{print $2, $3}')
            if [[ -n "$SNAP_DATE" ]]; then
                SNAP_TS=$(date -d "$SNAP_DATE" +%s 2>/dev/null || echo 0)
                AGE_DAYS=$(( (NOW_TS - SNAP_TS) / 86400 ))
                if [[ "$AGE_DAYS" -gt 30 ]]; then
                    warn "VM $VMID snap '$SNAP_NAME' umur ${AGE_DAYS}h"; FOUND_SNAP=1; SUM_SNAP_OLD=$((SUM_SNAP_OLD+1)); add_detail "VM $VMID snap '$SNAP_NAME' ${AGE_DAYS}h"
                    add_recommendation "Snapshot VM $VMID ('$SNAP_NAME') sudah tua. Hapus jika tidak perlu untuk hemat storage."
                fi
            fi
        done <<< "$SNAPS"
    fi
done
[[ "$FOUND_SNAP" -eq 0 ]] && ok "Tidak ada snapshot >30 hari"

section "24. PENDING UPDATES"
if command -v apt >/dev/null 2>&1; then
    UPDATES=$(apt list --upgradable 2>/dev/null | grep -c upgradable)
    SECURITY=$(apt list --upgradable 2>/dev/null | grep -ci security)
    printf "%-20s : %s\n" "Total Updates" "$UPDATES"
    printf "%-20s : %s\n" "Security Updates" "$SECURITY"
    SUM_UPDATES_SEC=$SECURITY
    [[ "$SECURITY" -gt 0 ]] && add_detail "Security updates: $SECURITY" && \
    add_recommendation "Ada update keamanan. Jadwalkan 'apt upgrade' saat maintenance window." || ok "No security updates"
fi

# ============================================
# TAHAP 7: KERNEL & REBOOT ASSESSMENT
# ============================================
section "25. KERNEL, BOOT & REBOOT ASSESSMENT"

RUNNING_KERNEL=$(uname -r)
INSTALLED_KERNEL=$(ls -v /boot/vmlinuz-* 2>/dev/null | tail -1 | sed 's|/boot/vmlinuz-||')
CANDIDATE_KERNEL=$(apt list --upgradable 2>/dev/null | grep -oP 'pve-kernel-\K[0-9.]+-pve' | tail -1)
[[ -z "$CANDIDATE_KERNEL" ]] && CANDIDATE_KERNEL="$INSTALLED_KERNEL"

BOOT_TOOL_STATUS="OK"
if command -v proxmox-boot-tool >/dev/null 2>&1; then
    BOOT_TOOL_RAW=$(proxmox-boot-tool status 2>&1)
    [[ "$BOOT_TOOL_RAW" == *"ERROR"* ]] && BOOT_TOOL_STATUS="ERROR"
fi
EFI_ENTRIES=$(efibootmgr 2>/dev/null | grep -c "Boot")
GRUB_CONFIG=$(grep '^GRUB_DEFAULT=' /etc/default/grub 2>/dev/null | cut -d= -f2)

KERNEL_HOLD="NONE"
apt-mark showhold 2>/dev/null | grep -q "pve-kernel" && KERNEL_HOLD="YES (Hati-hati, kernel di-hold)"

echo "[KERNEL]"
echo "Running Kernel       : $RUNNING_KERNEL"
echo "Installed Kernel     : $INSTALLED_KERNEL"
echo "Candidate Kernel     : $CANDIDATE_KERNEL"
echo ""
echo "[BOOT]"
echo "Boot Tool Status     : $BOOT_TOOL_STATUS"
echo "EFI Entries          : $EFI_ENTRIES (Ditemukan)"
echo "GRUB Configuration   : $GRUB_CONFIG"
echo ""
echo "[APT]"
echo "Kernel Package Hold  : $KERNEL_HOLD"
echo ""
echo "[ASSESSMENT]"

REBOOT_STATUS="NO"
if [[ "$RUNNING_KERNEL" != "$INSTALLED_KERNEL" ]]; then
    REBOOT_STATUS="YES"
    SUM_REBOOT_NEEDED=1
    echo -e "${RED}Running Kernel       : REVIEW (Berbeda dengan Installed)${NC}"
    echo -e "${YELLOW}Installed Kernel     : REVIEW (Butuh Reboot)${NC}"
    add_detail "Reboot Needed: Kernel $INSTALLED_KERNEL terinstall, running $RUNNING_KERNEL"
    add_recommendation "Migrasikan VM ke node lain, lalu lakukan REBOOT untuk menggunakan kernel terbaru."
elif [[ -f /var/run/reboot-required ]]; then
    REBOOT_STATUS="YES"
    SUM_REBOOT_NEEDED=1
    echo -e "${YELLOW}Running Kernel       : OK${NC}"
    echo -e "${YELLOW}System Status        : REVIEW (Ada file /var/run/reboot-required)${NC}"
    add_detail "Reboot Needed: File /var/run/reboot-required ditemukan"
    add_recommendation "Lakukan REBOOT saat maintenance window."
else
    echo -e "${GREEN}Running Kernel       : OK (Terbaru)${NC}"
    echo -e "${GREEN}Installed Kernel     : OK${NC}"
fi

echo "Boot Configuration   : $BOOT_TOOL_STATUS"
echo "APT Candidate        : $([ "$CANDIDATE_KERNEL" == "$INSTALLED_KERNEL" ] && echo "UP-TO-DATE" || echo "AVAILABLE")"
echo ""
if [[ "$REBOOT_STATUS" == "YES" ]]; then
    echo -e "${RED}${BOLD}[KESIMPULAN]: PERLU REBOOT${NC}"
    echo -e "${YELLOW}Server AMAN untuk direboot. Pastikan Boot Config OK (GRUB/EFI).${NC}"
else
    echo -e "${GREEN}${BOLD}[KESIMPULAN]: TIDAK PERLU REBOOT${NC}"
    echo -e "${GREEN}Server sudah menggunakan kernel terbaru.${NC}"
fi

# ============================================
# TAHAP 8: KESIMPULAN (AUTO SUMMARY)
# ============================================
section "AUTO SUMMARY"
TOTAL_ISSUE=0
(( SUM_HA_ERROR > 0 ))      && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_HA_ERROR))
(( SUM_SVC_DOWN > 0 ))      && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_SVC_DOWN))
(( SUM_DISK_WARN > 0 ))     && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_DISK_WARN))
(( SUM_FS_WARN > 0 ))       && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_FS_WARN))
(( SUM_IO_WARN > 0 ))       && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_IO_WARN))
(( SUM_ZFS_ISSUE > 0 ))     && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_ZFS_ISSUE))
(( SUM_CEPH_ISSUE > 0 ))    && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_CEPH_ISSUE))
(( SUM_DMESG_ERR > 0 ))     && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_DMESG_ERR))
(( SUM_QUORUM_OK == 0 ))    && TOTAL_ISSUE=$((TOTAL_ISSUE + 1))
(( SUM_SMART_MISSING > 0 )) && TOTAL_ISSUE=$((TOTAL_ISSUE + 1))
(( SUM_REPL_ERR > 0 ))      && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_REPL_ERR))
(( SUM_BACKUP_MISSING > 0 ))&& TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_BACKUP_MISSING))
(( SUM_TASK_FAIL > 0 ))     && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_TASK_FAIL))
(( SUM_NET_DOWN > 0 ))      && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_NET_DOWN))
(( SUM_LATENCY_WARN > 0 ))  && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_LATENCY_WARN))
(( SUM_UPDATES_SEC > 0 ))   && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_UPDATES_SEC))
(( SUM_REBOOT_NEEDED > 0 )) && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_REBOOT_NEEDED))
(( SUM_VM_LOCKED > 0 ))     && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_VM_LOCKED))
(( SUM_SNAP_OLD > 0 ))      && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_SNAP_OLD))
(( SUM_VM_PAUSED > 0 ))     && TOTAL_ISSUE=$((TOTAL_ISSUE + SUM_VM_PAUSED))

printf "%-30s : %s\n" "Node"                  "$(hostname)"
printf "%-30s : %s\n" "Waktu"                 "$(date '+%Y-%m-%d %H:%M:%S')"
printf "%-30s : %s\n" "Quorum"                "$([ $SUM_QUORUM_OK -eq 1 ] && echo OK || echo FAIL)"
printf "%-30s : %s\n" "HA Issues"             "$SUM_HA_ERROR"
printf "%-30s : %s\n" "Service Down"          "$SUM_SVC_DOWN"
printf "%-30s : %s\n" "VM Paused/Suspended"   "$SUM_VM_PAUSED"
printf "%-30s : %s\n" "VM Locked"             "$SUM_VM_LOCKED"
printf "%-30s : %s\n" "Disk Warning"          "$SUM_DISK_WARN"
printf "%-30s : %s\n" "FS Warning (>85%%)"     "$SUM_FS_WARN"
printf "%-30s : %s\n" "IO Wait Warning"       "$SUM_IO_WARN"
printf "%-30s : %s\n" "ZFS Issue"             "$SUM_ZFS_ISSUE"
printf "%-30s : %s\n" "Ceph Issue"            "$SUM_CEPH_ISSUE"
printf "%-30s : %s\n" "Backup Missing"        "$SUM_BACKUP_MISSING"
printf "%-30s : %s\n" "Task Fail (10 last)"   "$SUM_TASK_FAIL"
printf "%-30s : %s\n" "Network Down"          "$SUM_NET_DOWN"
printf "%-30s : %s\n" "Latency Warning"       "$SUM_LATENCY_WARN"
printf "%-30s : %s\n" "Security Updates"      "$SUM_UPDATES_SEC"
printf "%-30s : %s\n" "Reboot Needed"         "$([ $SUM_REBOOT_NEEDED -eq 1 ] && echo "YES" || echo "NO")"
printf "%-30s : %s\n" "Old Snapshots (>30h)"  "$SUM_SNAP_OLD"

echo ""
if [[ "$TOTAL_ISSUE" -eq 0 ]]; then
    echo -e "${GREEN}${BOLD}>>> STATUS: SEHAT — tidak ada masalah terdeteksi <<<${NC}"
else
    echo -e "${RED}${BOLD}>>> STATUS: PERLU PERHATIAN — $TOTAL_ISSUE item <<<${NC}"
    
    echo ""
    echo -e "${YELLOW}Detail masalah:${NC}"
    for D in "${SUMMARY_DETAILS[@]}"; do echo "   - $D"; done

    if [[ ${#RECOMMENDATIONS[@]} -gt 0 ]]; then
        echo ""
        echo -e "${PURPLE}${BOLD}REKOMENDASI TINDAKAN:${NC}"
        for R in "${RECOMMENDATIONS[@]}"; do echo "   - $R"; done
    fi
fi
echo "__RS_RESULT__: OK"
