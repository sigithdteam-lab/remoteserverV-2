#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

# Helper: Cek apakah IP ada di file kategori
_check_in_file() {
    local target="$1" file="$2"
    [[ -f "$file" ]] && grep -qxF "$target" "$file"
}

# Helper: Cek status known_hosts (YES/NO) berwarna
_check_kh_status() {
    local srv="$1"
    parse_server_string "$srv" || return
    local in_kh="NO"
    if [[ -f "$KNOWN_HOSTS" ]]; then
        local kh_key; kh_key=$(_known_hosts_key)
        ssh-keygen -F "$kh_key" -f "$KNOWN_HOSTS" >/dev/null 2>&1 && in_kh="YES"
    fi
    if [[ "$in_kh" == "YES" ]]; then
        printf "  %-35s known_hosts: ${GREEN}%s${NC}\n" "$srv" "$in_kh"
    else
        printf "  %-35s known_hosts: ${RED}%s${NC}\n" "$srv" "$in_kh"
    fi
}

list_show_categorized() {
    read_servers
    local all_servers=("${SERVERS_CACHED[@]}")
    
    local -a linux_srv=() px_srv=() whm_srv=()
    local s
    
    local px_file="$SCRIPT_DIR/proxmox-nodes.txt"
    local whm_file="$SCRIPT_DIR/whmcpanel.txt"

    for s in "${all_servers[@]}"; do
        if _check_in_file "$s" "$px_file"; then
            px_srv+=("$s")
        elif _check_in_file "$s" "$whm_file"; then
            whm_srv+=("$s")
        else
            linux_srv+=("$s")
        fi
    done

    echo ""
    echo -e "${CYAN}${BOLD}DAFTAR SERVER TERDAFTAR${NC}"
    echo ""
    
    if [[ ${#linux_srv[@]} -gt 0 ]]; then
        echo -e "${YELLOW}--- KATEGORI: LINUX (${#linux_srv[@]} Server) ---${NC}"
        local i=1
        for s in "${linux_srv[@]}"; do echo "  $i) $s"; i=$((i+1)); done
        echo ""
    fi

    if [[ ${#px_srv[@]} -gt 0 ]]; then
        echo -e "${YELLOW}--- KATEGORI: PROXMOX (${#px_srv[@]} Server) ---${NC}"
        local i=1
        for s in "${px_srv[@]}"; do echo "  $i) $s"; i=$((i+1)); done
        echo ""
    fi

    if [[ ${#whm_srv[@]} -gt 0 ]]; then
        echo -e "${YELLOW}--- KATEGORI: WHM/cPANEL (${#whm_srv[@]} Server) ---${NC}"
        local i=1
        for s in "${whm_srv[@]}"; do echo "  $i) $s"; i=$((i+1)); done
        echo ""
    fi

    echo -e "${CYAN}Total: ${#all_servers[@]} Server Terdaftar${NC}"
    pause
}

list_add_categorized() {
    echo ""
    echo -e "${CYAN}${BOLD}TAMBAH SERVER BARU${NC}"
    echo "Pilih Kategori:"
    echo "  1) Linux"
    echo "  2) Proxmox"
    echo "  3) WHM/cPanel"
    echo "  0) Batal"
    read -rp "Pilih (0-3): " cat_choice
    [[ "$cat_choice" == "0" ]] && return

    echo ""
    read -rp "Masukkan IP / Host (contoh: 10.20.30.2): " new_server
    new_server=$(echo "$new_server" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -z "$new_server" ]] && { error "Input kosong."; pause; return; }

    # Cek Duplikasi berdasarkan IP dan Port
    parse_server_string "$new_server" || { error "Format tidak valid."; pause; return; }
    local new_host="$_S_HOST"
    local new_port="$_S_PORT"
    local s_exist
    for s_exist in "${SERVERS_CACHED[@]}"; do
        if parse_server_string "$s_exist"; then
            if [[ "$_S_HOST" == "$new_host" && "$_S_PORT" == "$new_port" ]]; then
                error "Host $new_host:$new_port sudah ada di list (terdaftar sebagai: $s_exist)."
                pause
                return
            fi
        fi
    done

    # Tambah ke master list
    if ! grep -qxF "$new_server" "$SERVER_LIST" 2>/dev/null; then
        echo "$new_server" >> "$SERVER_LIST"
    fi
    refresh_servers
    
    # Tambah ke file kategori
    case "$cat_choice" in
        2)
            local px_file="$SCRIPT_DIR/proxmox-nodes.txt"
            grep -qxF "$new_server" "$px_file" 2>/dev/null || echo "$new_server" >> "$px_file"
            info "Ditambahkan ke proxmox-nodes.txt"
            ;;
        3)
            local whm_file="$SCRIPT_DIR/whmcpanel.txt"
            grep -qxF "$new_server" "$whm_file" 2>/dev/null || echo "$new_server" >> "$whm_file"
            info "Ditambahkan ke whmcpanel.txt"
            ;;
    esac
    info "Server $new_server berhasil ditambahkan."
    pause
}

list_remove_categorized() {
    echo ""
    echo -e "${CYAN}${BOLD}HAPUS SERVER${NC}"
    echo "Pilih Kategori yang ingin dihapus:"
    echo "  1) Linux"
    echo "  2) Proxmox"
    echo "  3) WHM/cPanel"
    echo "  0) Batal"
    read -rp "Pilih (0-3): " cat_choice
    [[ "$cat_choice" == "0" ]] && return

    local target_file="$SERVER_LIST"
    [[ "$cat_choice" == "2" ]] && target_file="$SCRIPT_DIR/proxmox-nodes.txt"
    [[ "$cat_choice" == "3" ]] && target_file="$SCRIPT_DIR/whmcpanel.txt"

    [[ ! -f "$target_file" ]] && { error "File kategori kosong/tidak ada."; pause; return; }
    
    echo ""
    echo "Daftar di kategori ini:"
    local -a list=()
    mapfile -t list < <(grep -v '^#' "$target_file" | sed '/^\s*$/d')
    if [[ ${#list[@]} -eq 0 ]]; then
        warn "Tidak ada server di kategori ini."
        pause; return
    fi
    
    local i=0
    for s in "${list[@]}"; do echo "  $((i+1))) $s"; i=$((i+1)); done

    read -rp "Masukkan nomor yang dihapus (0 batal): " num
    [[ "$num" == "0" ]] && return
    local idx=$((num-1))
    (( idx < 0 || idx >= ${#list[@]} )) && { error "Nomor tidak valid."; pause; return; }

    local target="${list[$idx]}"
    confirm_destructive "Hapus $target dari semua list?" "DELETE" || { pause; return; }

    # Hapus dari master list
    sed -i "\\|^$target$|d" "$SERVER_LIST"
    # Hapus dari file kategori
    [[ "$cat_choice" == "2" || "$cat_choice" == "3" ]] && sed -i "\\|^$target$|d" "$target_file"
    
    refresh_servers
    info "Server $target berhasil dihapus."
    pause
}

list_verify() {
    read_servers
    local all_servers=("${SERVERS_CACHED[@]}")
    
    local -a linux_srv=() px_srv=() whm_srv=()
    local s
    
    local px_file="$SCRIPT_DIR/proxmox-nodes.txt"
    local whm_file="$SCRIPT_DIR/whmcpanel.txt"

    # Kategorisasi
    for s in "${all_servers[@]}"; do
        if _check_in_file "$s" "$px_file"; then
            px_srv+=("$s")
        elif _check_in_file "$s" "$whm_file"; then
            whm_srv+=("$s")
        else
            linux_srv+=("$s")
        fi
    done

    echo ""
    echo -e "${CYAN}${BOLD}VERIFIKASI KONSISTENSI (known_hosts)${NC}"
    echo ""
    
    if [[ ${#linux_srv[@]} -gt 0 ]]; then
        echo -e "${YELLOW}--- KATEGORI: LINUX (${#linux_srv[@]} Server) ---${NC}"
        for s in "${linux_srv[@]}"; do _check_kh_status "$s"; done
        echo ""
    fi

    if [[ ${#px_srv[@]} -gt 0 ]]; then
        echo -e "${YELLOW}--- KATEGORI: PROXMOX (${#px_srv[@]} Server) ---${NC}"
        for s in "${px_srv[@]}"; do _check_kh_status "$s"; done
        echo ""
    fi

    if [[ ${#whm_srv[@]} -gt 0 ]]; then
        echo -e "${YELLOW}--- KATEGORI: WHM/cPANEL (${#whm_srv[@]} Server) ---${NC}"
        for s in "${whm_srv[@]}"; do _check_kh_status "$s"; done
        echo ""
    fi

    echo -e "${CYAN}Total: ${#all_servers[@]} Server Terverifikasi${NC}"
    pause
}

ssh_management_menu() {
    while true; do
        echo ""
        echo -e "${CYAN}${BOLD}SSH & SERVER LIST MANAGEMENT${NC}"
        echo -e "${YELLOW}--- Server List ---${NC}"
        echo "1. Lihat list server (Kategori)"
        echo "2. Tambah server (dengan kategori)"
        echo "3. Hapus server (Berdasarkan Kategori)"
        echo "4. Verifikasi konsistensi (Semua)"
        echo ""
        echo -e "${YELLOW}--- Koneksi ---${NC}"
        echo "5. Remote SSH (manual)"
        echo "6. Remote SSH (from list)"
        echo ""
        echo "0. Back"
        echo -n "Pilih (0-6): "
        read -r c
        case "$c" in
            1) list_show_categorized ;;
            2) list_add_categorized ;;
            3) list_remove_categorized ;;
            4) list_verify ;;
            5) remote_ssh_manual ;;
            6) remote_ssh_from_list ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
