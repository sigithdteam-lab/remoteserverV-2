#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

whm_menu() {
    local whm_file="$SCRIPT_DIR/whmcpanel.txt"
    
    if [[ ! -f "$whm_file" ]]; then
        error "File whmcpanel.txt tidak ditemukan."
        info "Buat file tersebut dan isi dengan IP server WHM."
        pause
        return 1
    fi

    local -a whm_servers=()
    mapfile -t whm_servers < <(grep -v '^#' "$whm_file" | sed '/^\s*$/d')
    if [[ ${#whm_servers[@]} -eq 0 ]]; then
        error "Daftar server WHM kosong."
        pause
        return 1
    fi

    echo ""
    echo -e "${CYAN}${BOLD}WHM/cPANEL MANAGEMENT${NC}"
    echo "Daftar Server:"
    local i=0
    for s in "${whm_servers[@]}"; do echo "  $((i+1))) $s"; i=$((i+1)); done
    echo "  0) Batal"
    
    read -rp "Pilih Server (0-${#whm_servers[@]}): " choice
    [[ "$choice" == "0" ]] && return
    
    local idx=$((choice-1))
    (( idx < 0 || idx >= ${#whm_servers[@]} )) && { error "Pilihan tidak valid."; pause; return 1; }

    local target="${whm_servers[$idx]}"
    info "Menghubungkan ke $target ..."

    # Persiapkan argumen SSH
    if ! parse_server_string "$target"; then
        error "Format server tidak valid."
        pause; return 1
    fi
    
    local tgt; tgt=$(_ssh_target)
    local -a opts; mapfile -t opts < <(build_ssh_opts "$_S_PORT")
    
    echo ""
    info "Menjalankan WHM Management Script di $target..."
    info "Catatan: Jika script whmcpanel.sh belum ada di /root/, Anda harus menguploadnya terlebih dahulu."
    echo ""
    
    # Jalankan SSH dengan force TTY (-t) karena script WHM sangat interaktif
    ssh -t "${opts[@]}" "$tgt" "if [[ -f /root/whmcpanel.sh ]]; then bash /root/whmcpanel.sh; else echo 'ERROR: File /root/whmcpanel.sh tidak ditemukan di server target.'; fi"
    
    echo ""
    info "Kembali ke Controller."
    pause
}
