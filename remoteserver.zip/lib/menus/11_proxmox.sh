#!/bin/bash
# ============================================================
# GNU General Public License v3.0
# November 2026 sigit-hdteamlabs <sigit.hdteam@gmail.com>
# ============================================================

# ── FUNGSI BANTU: Baca List Node ──
_get_proxmox_nodes() {
    local plist="$SCRIPT_DIR/proxmox-nodes.txt"
    if [[ ! -f "$plist" ]]; then
        error "File '$plist' tidak ditemukan."
        return 1
    fi
    mapfile -t P_NODES < <(grep -v '^[[:space:]]*$' "$plist" | grep -v '^[[:space:]]*#')
    if [[ ${#P_NODES[@]} -eq 0 ]]; then
        error "File '$plist' kosong."
        return 1
    fi
}

# ── FUNGSI BANTU: Eksekusi Cek Proxmox ──
_run_proxmox_check() {
    local node="$1"
    local script_file="$LIB_DIR/remote_scripts/proxmox_check.sh"
    
    if [[ ! -f "$script_file" ]]; then
        error "Script remote proxmox_check.sh tidak ada!"
        return 1
    fi
    
    local script; script=$(cat "$script_file")
    
    echo ""
    echo -e "${CYAN}${BOLD}[INFO] Memeriksa Node: $node${NC}"
    echo ""
    
    # Eksekusi via cel_remote_read
    local rc=0
    cel_remote_read "$node" "Proxmox Cluster Check" "$script" || rc=$?
    
    echo ""
    if (( rc == 0 )); then
        echo -e "${GREEN}>>> Pengecekan Node $node SELESAI.${NC}"
    else
        echo -e "${RED}>>> Pengecekan Node $node GAGAL (Exit code: $rc).${NC}"
    fi
    return $rc
}

# ── OPSI 1: Pilih Satu Node ──
proxmox_check_single() {
    _get_proxmox_nodes || return 1
    
    echo ""
    echo -e "${CYAN}${BOLD}  PILIH NODE PROXMOX${NC}"
    echo ""
    local i
    for i in "${!P_NODES[@]}"; do
        printf "  %3d) %s\n" "$((i+1))" "${P_NODES[$i]}"
    done
    echo ""
    
    read -rp "Masukkan nomor node (atau 0 untuk batal): " choice
    [[ "$choice" == "0" ]] && return 0
    [[ ! "$choice" =~ ^[0-9]+$ ]] && { error "Input tidak valid."; return 1; }
    
    local idx=$((choice - 1))
    if (( idx < 0 || idx >= ${#P_NODES[@]} )); then
        error "Nomor di luar jangkauan."
        return 1
    fi
    
    local target="${P_NODES[$idx]}"
    _run_proxmox_check "$target"
}

# ── OPSI 2: Cek Semua Node (Berurutan) ──
proxmox_check_all() {
    _get_proxmox_nodes || return 1
    
    info "Memulai Pengecekan SEMUA Node Proxmox (${#P_NODES[@]} server)..."
    warn "Proses ini mungkin memakan waktu."
    if ! confirm_action "Lanjutkan?"; then
        return 0
    fi

    local total=${#P_NODES[@]}
    local n=0
    local ok=0
    local fail=0
    local -a summary_results=()

    for node in "${P_NODES[@]}"; do
        n=$((n+1))
        show_progress "$n" "$total" "$node"
        
        # Jalankan check
        _run_proxmox_check "$node"
        local rc=$?
        
        if (( rc == 0 )); then
            ok=$((ok+1))
            summary_results+=("OK|$node")
        else
            fail=$((fail+1))
            summary_results+=("FAIL|$node")
        fi
        echo ""
    done

    # Ringkasan Akhir
    echo -e "${CYAN}${BOLD}  RINGKASAN PENGECEKAN SEMUA NODE${NC}"
    printf "  %-4s | %-30s | %-10s\n" "#" "Node" "Status"
    printf "  %-4s-|-%-30s-|-%-10s\n" "----" "------------------------------" "----------"
    
    local i
    for i in "${!summary_results[@]}"; do
        IFS='|' read -r status node_name <<< "${summary_results[$i]}"
        local color="${RED}"
        [[ "$status" == "OK" ]] && color="${GREEN}"
        printf "  %-4d | %-30s | ${color}%-10s${NC}\n" "$((i+1))" "$node_name" "$status"
    done
    info "Total: $total | Sukses: $ok | Gagal: $fail"
}

# ── MENU 11 UTAMA ──
proxmox_menu() {
    while true; do
        echo ""
        echo -e "${CYAN}${BOLD}  PROXMOX CLUSTER CHECK${NC}"
        echo ""
        echo "1. Pilih Satu Node (Spesifik)"
        echo "2. Cek Semua Node (All)"
        echo ""
        echo "0. Back"
        echo ""
        echo -n "Pilih (0-2): "
        read -r c
        case "$c" in
            1) proxmox_check_single ;;
            2) proxmox_check_all ;;
            0) break ;;
            *) warn "Invalid" ;;
        esac
    done
}
